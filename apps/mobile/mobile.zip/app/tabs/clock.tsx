import { useState, useEffect, useCallback } from 'react';
import { View, Text, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import { apiFetch } from '../../src/store/auth';
import { DARK as T } from '../../src/components/ui';

type ClockRecord = {
  id: string;
  date: string;  
  clocked_in_at: string;
  clocked_out_at: string | null;
  duration_mins:  number | null;
  location_in:    string | null;
  location_out:   string | null;
};

function fmtTime(iso: string) {
  return new Date(iso).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
}
function fmtDuration(mins: number) {
  return `${Math.floor(mins / 60)}h ${mins % 60}m`;
}

export default function ClockScreen() {
  const [record,   setRecord]   = useState<ClockRecord | null>(null);
  const [loading,  setLoading]  = useState(true);
  const [acting,   setActing]   = useState(false);
  const [elapsed,  setElapsed]  = useState(0);  // minutes since clock-in
  const [weekData, setWeekData] = useState<ClockRecord[]>([]);

  const refresh = useCallback(async () => {
    try {
      const [today, week] = await Promise.all([
        apiFetch<ClockRecord | null>('/api/attendance/today'),
        apiFetch<ClockRecord[]>('/api/attendance/week'),
      ]);
      setRecord(today ?? null);
      setWeekData(week ?? []);
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  // Live elapsed timer
  useEffect(() => {
    if (!record?.clocked_in_at || record.clocked_out_at) return;
    const tick = () => setElapsed(Math.round((Date.now() - new Date(record.clocked_in_at).getTime()) / 60000));
    tick();
    const iv = setInterval(tick, 10_000);
    return () => clearInterval(iv);
  }, [record]);

  const isClockedIn  = !!record?.clocked_in_at && !record.clocked_out_at;
  const isClockedOut = !!record?.clocked_out_at;

  const getLocation = async (): Promise<string | undefined> => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') return undefined;
    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    return `${loc.coords.latitude.toFixed(5)},${loc.coords.longitude.toFixed(5)}`;
  };

  const handleClock = async () => {
    setActing(true);
    try {
      const location = await getLocation();
      if (isClockedIn) {
        await apiFetch('/api/attendance/clock-out', {
          method: 'POST', body: JSON.stringify({ location }),
        });
      } else {
        await apiFetch('/api/attendance/clock-in', {
          method: 'POST', body: JSON.stringify({ location }),
        });
      }
      await refresh();
    } catch (e: any) {
      Alert.alert('Error', e.message ?? 'Failed');
    } finally { setActing(false); }
  };

  // Progress: 480 mins = 8h working day
  const progressPct = Math.min(100, isClockedIn ? (elapsed / 480) * 100 : 0);
  const ringColor   = isClockedIn ? T.success : T.border;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: T.bg }}>
      <ScrollView contentContainerStyle={{ padding: 20 }}>

        {/* Header */}
        <Text style={{ color: T.muted, fontSize: 12, marginBottom: 4 }}>
          {new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}
        </Text>
        <Text style={{ color: T.text, fontSize: 22, fontWeight: '900', marginBottom: 28 }}>Attendance</Text>

        {/* Status card */}
        <View style={{
          backgroundColor: T.card, borderRadius: 24, padding: 32, alignItems: 'center',
          borderWidth: 1, borderColor: isClockedIn ? T.success + '44' : T.border,
          marginBottom: 20,
          shadowColor: isClockedIn ? T.success : '#000', shadowOffset: { width: 0, height: 8 },
          shadowOpacity: isClockedIn ? 0.2 : 0.1, shadowRadius: 20, elevation: 8,
        }}>
          {/* Status indicator */}
          <View style={{
            width: 16, height: 16, borderRadius: 8,
            backgroundColor: isClockedIn ? T.success : isClockedOut ? T.muted : T.dim,
            marginBottom: 16,
            shadowColor: isClockedIn ? T.success : 'transparent',
            shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.8, shadowRadius: 8,
          }} />

          <Text style={{ color: T.muted, fontSize: 13, marginBottom: 4 }}>
            {isClockedIn ? 'Currently working' : isClockedOut ? 'Day complete' : 'Not started'}
          </Text>

          {isClockedIn && (
            <>
              <Text style={{ color: T.success, fontSize: 48, fontWeight: '900', letterSpacing: -2 }}>
                {fmtDuration(elapsed)}
              </Text>
              <Text style={{ color: T.dim, fontSize: 12, marginTop: 4 }}>
                Since {fmtTime(record!.clocked_in_at)}
              </Text>
            </>
          )}

          {isClockedOut && (
            <>
              <Text style={{ color: T.text, fontSize: 40, fontWeight: '900', letterSpacing: -1 }}>
                {fmtDuration(record!.duration_mins!)}
              </Text>
              <View style={{ flexDirection: 'row', gap: 24, marginTop: 16 }}>
                <View style={{ alignItems: 'center' }}>
                  <Text style={{ color: T.text, fontSize: 18, fontWeight: '800' }}>{fmtTime(record!.clocked_in_at)}</Text>
                  <Text style={{ color: T.dim, fontSize: 10 }}>Clock In</Text>
                </View>
                <View style={{ alignItems: 'center' }}>
                  <Text style={{ color: T.text, fontSize: 18, fontWeight: '800' }}>{fmtTime(record!.clocked_out_at!)}</Text>
                  <Text style={{ color: T.dim, fontSize: 10 }}>Clock Out</Text>
                </View>
              </View>
            </>
          )}

          {!isClockedIn && !isClockedOut && (
            <Text style={{ color: T.text, fontSize: 48, fontWeight: '900', letterSpacing: -2 }}>
              {new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
            </Text>
          )}
        </View>

        {/* Progress bar */}
        {isClockedIn && (
          <View style={{ marginBottom: 20 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
              <Text style={{ color: T.dim, fontSize: 11 }}>Progress toward 8h day</Text>
              <Text style={{ color: T.success, fontSize: 11, fontWeight: '700' }}>{Math.round(progressPct)}%</Text>
            </View>
            <View style={{ backgroundColor: T.border, borderRadius: 99, height: 6 }}>
              <View style={{ width: `${progressPct}%`, height: '100%', backgroundColor: T.success, borderRadius: 99 }} />
            </View>
          </View>
        )}

        {/* Clock In/Out button */}
        {!isClockedOut && (
          <TouchableOpacity
            onPress={handleClock}
            disabled={acting || loading}
            activeOpacity={0.85}
            style={{
              backgroundColor: isClockedIn ? T.danger : T.success,
              borderRadius: 18, padding: 20, alignItems: 'center', marginBottom: 24,
              opacity: acting ? 0.7 : 1,
              shadowColor: isClockedIn ? T.danger : T.success,
              shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.35, shadowRadius: 16, elevation: 10,
            }}
          >
            <Text style={{ color: '#fff', fontSize: 20, fontWeight: '900' }}>
              {acting ? '...' : isClockedIn ? '🏁  Clock Out' : '✅  Clock In'}
            </Text>
            <Text style={{ color: 'rgba(255,255,255,0.7)', fontSize: 12, marginTop: 4 }}>
              {isClockedIn ? 'Records your finish time and location' : 'Records your start time and location'}
            </Text>
          </TouchableOpacity>
        )}

        {isClockedOut && (
          <View style={{ alignItems: 'center', marginBottom: 24 }}>
            <Text style={{ color: T.success, fontSize: 18, fontWeight: '800' }}>🎉 Great work today!</Text>
            <Text style={{ color: T.dim, fontSize: 13, marginTop: 4 }}>See you tomorrow</Text>
          </View>
        )}

        {/* This week */}
        {weekData.length > 1 && (
          <>
            <Text style={{ color: T.text, fontSize: 15, fontWeight: '800', marginBottom: 12 }}>This week</Text>
            {weekData.filter(r => r.date !== new Date().toISOString().split('T')[0]).slice(0, 4).map(r => (
              <View key={r.id} style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: T.elevated, borderRadius: 12, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: T.border }}>
                <View>
                  <Text style={{ color: T.text, fontSize: 13, fontWeight: '700' }}>
                    {new Date(r.date).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric' })}
                  </Text>
                  <Text style={{ color: T.dim, fontSize: 11 }}>
                    {fmtTime(r.clocked_in_at)} → {r.clocked_out_at ? fmtTime(r.clocked_out_at) : 'Open'}
                  </Text>
                </View>
                <Text style={{ color: r.duration_mins ? T.success : T.warning, fontSize: 15, fontWeight: '900' }}>
                  {r.duration_mins ? fmtDuration(r.duration_mins) : '—'}
                </Text>
              </View>
            ))}
          </>
        )}

      </ScrollView>
    </SafeAreaView>
  );
}
