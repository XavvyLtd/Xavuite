export default { key:'sos', title:'SOS Alerts', icon:'🚨', group: 'facilities', permissions:[], navigation:[{ label:'SOS Alerts', path:'/sos', permission:null }] };
