/**
 * hooks/api.ts
 *
 * Backward-compatible barrel export.
 * All hooks remain importable from this path — no existing imports break.
 *
 * Internal structure:
 *   - Shared primitives → platform/auth/apiClient.ts
 *   - All types        → platform/types/index.ts
 *   - Module selectors → modules/{module}/hooks/
 *
 * TODO(migration): Progressively move module-specific hooks into their
 *   own modules/{module}/hooks/ files and update imports.
 */

// Re-export platform primitives (backward compat)
export { useApi, useApiMutation } from '../platform/auth/apiClient';

// Re-export all types (backward compat)
export type {
  PaginationMeta, Employee, EmployeeHistory, Dept,
  LeaveRequest, Timesheet, TimesheetEntry,
  ExpenseClaim, RTWCheck,
  Project, Task, Sprint,
  JobPosting, Document, Asset,
  TrainingCourse, TrainingAssignment,
  Announcement, AuditEvent,
} from '../platform/types';

import { useApi, useApiMutation } from '../platform/auth/apiClient';

// ── Dashboard ─────────────────────────────────────────────────────────────────
export function useDashboard() {
  return useApi<{ metrics: Record<string, number>; recentActivity: unknown[] }>(
    ['dashboard'], '/api/dashboard', { refetchInterval: 30_000 }
  );
}

// ── Employees ─────────────────────────────────────────────────────────────────
import type { Employee, EmployeeHistory, Dept, PaginationMeta } from '../platform/types';

export function useEmployees(params?: Record<string, string>) {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return useApi<{ items: Employee[]; meta: PaginationMeta }>(['employees', params], `/api/employees${qs}`);
}
export function useEmployee(id: string) {
  return useApi<Employee>(['employees', id], `/api/employees/${id}`, { enabled: !!id });
}
export function useEmployeeHistory(id: string) {
  return useApi<EmployeeHistory[]>(['employees', id, 'history'], `/api/employees/${id}/history`, { enabled: !!id });
}
export function useCreateEmployee() {
  return useApiMutation('/api/employees', 'POST', [['employees']]);
}
export function useUpdateEmployee(id: string) {
  return useApiMutation(`/api/employees/${id}`, 'PATCH', [['employees'], ['employees', id]]);
}
export function useDepartments() {
  return useApi<Dept[]>(['departments'], '/api/departments');
}

// ── Leave ─────────────────────────────────────────────────────────────────────
import type { LeaveRequest } from '../platform/types';

export function useLeaveRequests(params?: Record<string, string>) {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return useApi<LeaveRequest[]>(['leave', params], `/api/leave${qs}`);
}
export function useCreateLeave() {
  return useApiMutation('/api/leave', 'POST', [['leave']]);
}
export function useLeaveDecision(id: string) {
  return useApiMutation(`/api/leave/${id}/decision`, 'POST', [['leave']]);
}

// ── Timesheets ────────────────────────────────────────────────────────────────
import type { Timesheet, TimesheetEntry } from '../platform/types';

export function useTimesheets(params?: Record<string, string>) {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return useApi<Timesheet[]>(['timesheets', params], `/api/timesheets${qs}`);
}
export function useTimesheetDetail(id: string) {
  return useApi<Timesheet & { entries: TimesheetEntry[] }>(['timesheets', id], `/api/timesheets/${id}`, { enabled: !!id });
}
export function useSubmitTimesheet() {
  return useApiMutation('/api/timesheets', 'POST', [['timesheets']]);
}
export function useTimesheetDecision(id: string) {
  return useApiMutation(`/api/timesheets/${id}/decision`, 'POST', [['timesheets']]);
}
export function useBulkTimesheetDecision() {
  return useApiMutation('/api/timesheets/bulk-decision', 'POST', [['timesheets']]);
}

// ── Expenses ──────────────────────────────────────────────────────────────────
import type { ExpenseClaim } from '../platform/types';

export function useExpenses(params?: Record<string, string>) {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return useApi<ExpenseClaim[]>(['expenses', params], `/api/expenses${qs}`);
}
export function useCreateExpense() {
  return useApiMutation('/api/expenses', 'POST', [['expenses']]);
}
export function useExpenseDecision(id: string) {
  return useApiMutation(`/api/expenses/${id}/decision`, 'POST', [['expenses']]);
}

// ── Compliance ────────────────────────────────────────────────────────────────
import type { RTWCheck } from '../platform/types';

export function useCompliance(params?: Record<string, string>) {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return useApi<RTWCheck[]>(['compliance', params], `/api/compliance${qs}`);
}
export function useCreateRTW() {
  return useApiMutation('/api/compliance', 'POST', [['compliance']]);
}

// ── PMO ───────────────────────────────────────────────────────────────────────
import type { Project, Task, Sprint } from '../platform/types';

export function useProjects() {
  return useApi<Project[]>(['pmo', 'projects'], '/api/pmo/projects');
}
export function useCreateProject() {
  return useApiMutation('/api/pmo/projects', 'POST', [['pmo', 'projects']]);
}
export function useTasks(params?: Record<string, string>) {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return useApi<Task[]>(['pmo', 'tasks', params], `/api/pmo/tasks${qs}`);
}
export function useCreateTask() {
  return useApiMutation('/api/pmo/tasks', 'POST', [['pmo', 'tasks']]);
}
export function useUpdateTask(id: string) {
  return useApiMutation(`/api/pmo/tasks/${id}`, 'PATCH', [['pmo', 'tasks']]);
}
export function useSprints() {
  return useApi<Sprint[]>(['pmo', 'sprints'], '/api/pmo/sprints');
}

// ── Recruitment ───────────────────────────────────────────────────────────────
import type { JobPosting } from '../platform/types';

export function useJobs() {
  return useApi<JobPosting[]>(['recruitment', 'jobs'], '/api/recruitment');
}
export function useCreateJob() {
  return useApiMutation('/api/recruitment', 'POST', [['recruitment', 'jobs']]);
}

// ── Documents ─────────────────────────────────────────────────────────────────
import type { Document } from '../platform/types';

export function useDocuments(params?: Record<string, string>) {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return useApi<Document[]>(['documents', params], `/api/documents${qs}`);
}

// ── Assets ────────────────────────────────────────────────────────────────────
import type { Asset } from '../platform/types';

export function useAssets(params?: Record<string, string>) {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return useApi<Asset[]>(['assets', params], `/api/assets${qs}`);
}
export function useCreateAsset() {
  return useApiMutation('/api/assets', 'POST', [['assets']]);
}
export function useAssignAsset(id: string) {
  return useApiMutation(`/api/assets/${id}/assign`, 'POST', [['assets']]);
}

// ── Training ──────────────────────────────────────────────────────────────────
import type { TrainingCourse, TrainingAssignment } from '../platform/types';

export function useTrainingCourses() {
  return useApi<TrainingCourse[]>(['training', 'courses'], '/api/training');
}
export function useTrainingAssignments(params?: Record<string, string>) {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return useApi<TrainingAssignment[]>(['training', 'assignments', params], `/api/training/assignments${qs}`);
}

// ── Announcements ─────────────────────────────────────────────────────────────
import type { Announcement } from '../platform/types';

export function useAnnouncements() {
  return useApi<Announcement[]>(['announcements'], '/api/announcements', { refetchInterval: 60_000 });
}
export function useCreateAnnouncement() {
  return useApiMutation('/api/announcements', 'POST', [['announcements']]);
}

// ── Audit ─────────────────────────────────────────────────────────────────────
import type { AuditEvent } from '../platform/types';

export function useAuditLog(page = 1) {
  return useApi<{ items: AuditEvent[]; meta: PaginationMeta }>(
    ['audit', page], `/api/audit?page=${page}&limit=50`
  );
}

// ── Scheduler ─────────────────────────────────────────────────────────────────
export interface ScheduledJob {
  id:               string;
  key:              string;
  name:             string;
  description?:     string;
  category:         string;
  enabled:          number;
  schedule_type:    string;
  cron_expr?:       string;
  interval_mins?:   number;
  email_to:         string;
  email_to_custom?: string;
  email_subject:    string;
  email_body:       string;
  trigger_config?:  string;
  last_run_at?:     string;
  last_run_status?: string;
  run_count:        number;
  total_runs:       number;
  error_runs:       number;
}

export interface JobRunLog {
  id:                  string;
  job_id:              string;
  triggered_by:        string;
  status:              string;
  started_at:          string;
  finished_at?:        string;
  duration_ms?:        number;
  emails_sent:         number;
  records_processed:   number;
  error_message?:      string;
  output?:             string;
}

export function useScheduledJobs() {
  return useApi<ScheduledJob[]>(['scheduler'], '/api/scheduler');
}
export function useJobRunLog(jobId: string) {
  return useApi<JobRunLog[]>(['scheduler', jobId, 'logs'], `/api/scheduler/${jobId}/logs`, { enabled: !!jobId });
}
export function useFireJob(id: string) {
  return useApiMutation(`/api/scheduler/${id}/fire`, 'POST', [['scheduler']]);
}
export function useCreateScheduledJob() {
  return useApiMutation('/api/scheduler', 'POST', [['scheduler']]);
}
export function useUpdateScheduledJob(id: string) {
  return useApiMutation(`/api/scheduler/${id}`, 'PATCH', [['scheduler']]);
}
export function useDeleteScheduledJob(id: string) {
  return useApiMutation(`/api/scheduler/${id}`, 'DELETE', [['scheduler']]);
}

// ── Workflow ──────────────────────────────────────────────────────────────────
export interface WorkflowDefinition {
  id:           string;
  key:          string;
  name:         string;
  description?: string;
  module:       string;
  enabled:      number;
  step_count:   number;
  active_count: number;
}
export interface WorkflowStep {
  id:             string;
  step_order:     number;
  name:           string;
  step_type:      string;
  approver_type:  string;
  approver_role?: string;
  sla_hours?:     number;
  condition?:     string;
  step_status?:   string;
}
export interface WorkflowInstance {
  id:                string;
  definition_key:    string;
  workflow_name:     string;
  module:            string;
  record_type:       string;
  record_id:         string;
  status:            string;
  current_step:      number;
  current_step_name: string;
  submitted_by_email:string;
  submitted_at:      string;
  sla_deadline?:     string;
  decided_at?:       string;
  outcome?:          string;
}
export interface WorkflowAction {
  id:          string;
  step_name:   string;
  actor_email: string;
  action:      string;
  comment?:    string;
  created_at:  string;
}

export function useWorkflowDefinitions() {
  return useApi<WorkflowDefinition[]>(['workflow', 'definitions'], '/api/workflows/definitions');
}
export function useWorkflowSteps(defId: string) {
  return useApi<WorkflowStep[]>(['workflow', 'steps', defId], `/api/workflows/definitions/${defId}/steps`, { enabled: !!defId });
}
export function usePendingApprovals() {
  return useApi<WorkflowInstance[]>(['workflow', 'pending'], '/api/workflows/pending', { refetchInterval: 30_000 });
}
export function useWorkflowInstances(params?: Record<string, string>) {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return useApi<WorkflowInstance[]>(['workflow', 'instances', params], `/api/workflows/instances${qs}`);
}
export function useWorkflowInstance(id: string) {
  return useApi<WorkflowInstance & { actions: WorkflowAction[]; steps: WorkflowStep[] }>(
    ['workflow', 'instances', id], `/api/workflows/instances/${id}`, { enabled: !!id }
  );
}
export function useTakeWorkflowAction(instanceId: string) {
  return useApiMutation(`/api/workflows/instances/${instanceId}/action`, 'POST', [['workflow']]);
}
export function useToggleWorkflow(id: string) {
  return useApiMutation(`/api/workflows/definitions/${id}`, 'PATCH', [['workflow', 'definitions']]);
}

// ── Recruitment (full pipeline) ───────────────────────────────────────────────
export interface Requisition {
  id:              string;
  title:           string;
  department_name?:string;
  location?:       string;
  location_type:   string;
  headcount:       number;
  priority:        string;
  status:          string;
  salary_min?:     number;
  salary_max?:     number;
  currency:        string;
  target_start?:   string;
  posting_count:   number;
  created_at:      string;
}
export interface Candidate {
  id:               string;
  first_name:       string;
  last_name:        string;
  email:            string;
  phone?:           string;
  location?:        string;
  linkedin_url?:    string;
  source:           string;
  tags?:            string;
  status:           string;
  application_count:number;
  applied_to?:      string;
  created_at:       string;
}
export interface Application {
  id:              string;
  job_id:          string;
  candidate_id:    string;
  first_name:      string;
  last_name:       string;
  candidate_email: string;
  stage:           string;
  stage_order:     number;
  source:          string;
  applied_at:      string;
  cv_score?:       number;
}
export interface Interview {
  id:              string;
  application_id:  string;
  stage_name:      string;
  interview_type:  string;
  scheduled_at:    string;
  duration_mins:   number;
  location?:       string;
  status:          string;
  score?:          number;
  feedback?:       string;
  recommendation?: string;
  candidate_name:  string;
  candidate_email: string;
  job_title:       string;
}
export interface Offer {
  id:             string;
  candidate_name: string;
  candidate_email:string;
  job_title:      string;
  salary:         number;
  currency:       string;
  status:         string;
  start_date?:    string;
  sent_at?:       string;
  expires_at?:    string;
}
export interface PipelineJob {
  id:          string;
  title:       string;
  status:      string;
  total:       number;
  applied:     number;
  screening:   number;
  phone_screen:number;
  interview:   number;
  offer:       number;
  hired:       number;
  rejected:    number;
}

export function useRequisitions(params?: Record<string,string>) {
  const qs = params ? '?'+new URLSearchParams(params).toString() : '';
  return useApi<Requisition[]>(['recruitment','requisitions',params], `/api/recruitment/requisitions${qs}`);
}
export function useCreateRequisition() {
  return useApiMutation('/api/recruitment/requisitions','POST',[['recruitment','requisitions']]);
}
export function useCandidates(params?: Record<string,string>) {
  const qs = params ? '?'+new URLSearchParams(params).toString() : '';
  return useApi<Candidate[]>(['recruitment','candidates',params], `/api/recruitment/candidates${qs}`);
}
export function useCandidate(id: string) {
  return useApi<Candidate & {applications:Application[];interviews:Interview[]}>(['recruitment','candidates',id], `/api/recruitment/candidates/${id}`, {enabled:!!id});
}
export function useCreateCandidate() {
  return useApiMutation('/api/recruitment/candidates','POST',[['recruitment','candidates']]);
}
export function useUpdateCandidate(id: string) {
  return useApiMutation(`/api/recruitment/candidates/${id}`,'PATCH',[['recruitment','candidates']]);
}
export function useRecruitmentJobs(params?: Record<string,string>) {
  const qs = params ? '?'+new URLSearchParams(params).toString() : '';
  return useApi<JobPosting[]>(['recruitment','jobs',params], `/api/recruitment/jobs${qs}`);
}
export function useRecruitmentJob(id: string) {
  return useApi<JobPosting & {applications:Application[]}>(['recruitment','jobs',id], `/api/recruitment/jobs/${id}`, {enabled:!!id});
}
export function useCreateRecruitmentJob() {
  return useApiMutation('/api/recruitment/jobs','POST',[['recruitment','jobs']]);
}
export function usePublishJob(id: string) {
  return useApiMutation(`/api/recruitment/jobs/${id}/publish`,'POST',[['recruitment','jobs']]);
}
export function useRecruitmentPipeline() {
  return useApi<PipelineJob[]>(['recruitment','pipeline'], '/api/recruitment/pipeline');
}
export function useCreateApplication() {
  return useApiMutation('/api/recruitment/applications','POST',[['recruitment']]);
}
export function useMoveApplicationStage(id: string) {
  return useApiMutation(`/api/recruitment/applications/${id}/stage`,'PATCH',[['recruitment']]);
}
export function useInterviews(params?: Record<string,string>) {
  const qs = params ? '?'+new URLSearchParams(params).toString() : '';
  return useApi<Interview[]>(['recruitment','interviews',params], `/api/recruitment/interviews${qs}`);
}
export function useScheduleInterview() {
  return useApiMutation('/api/recruitment/interviews','POST',[['recruitment','interviews']]);
}
export function useInterviewFeedback(id: string) {
  return useApiMutation(`/api/recruitment/interviews/${id}/feedback`,'POST',[['recruitment','interviews']]);
}
export function useOffers() {
  return useApi<Offer[]>(['recruitment','offers'], '/api/recruitment/offers');
}
export function useCreateOffer() {
  return useApiMutation('/api/recruitment/offers','POST',[['recruitment','offers']]);
}
export function useSendOffer(id: string) {
  return useApiMutation(`/api/recruitment/offers/${id}/send`,'POST',[['recruitment','offers']]);
}

// ── Leave Enhancements ────────────────────────────────────────────────────────
export interface LeaveType {
  id:               string;
  name:             string;
  code:             string;
  colour:           string;
  paid:             number;
  max_days?:        number;
  carry_forward:    number;
  carry_forward_max:number;
  half_day_allowed: number;
  enabled:          number;
}
export interface LeaveBalance {
  id:             string;
  employee_id:    string;
  employee_name:  string;
  leave_type_id:  string;
  leave_type_name:string;
  colour:         string;
  code:           string;
  year:           number;
  entitlement:    number;
  accrued:        number;
  taken:          number;
  pending:        number;
  carried_forward:number;
  adjusted:       number;
  remaining:      number;
}
export interface PublicHoliday {
  id:     string;
  name:   string;
  date:   string;
  region: string;
  year:   number;
}
export interface LeaveCalendarDay {
  leaves:   any[];
  holidays: PublicHoliday[];
}

export function useLeaveTypes() {
  return useApi<LeaveType[]>(['leave','types'], '/api/leave/types');
}
export function useLeaveBalances(params?: Record<string,string>) {
  const qs = params ? '?'+new URLSearchParams(params).toString() : '';
  return useApi<LeaveBalance[]>(['leave','balances',params], `/api/leave/balances${qs}`);
}
export function useEmployeeLeaveBalances(employeeId: string, year?: number) {
  return useApi<LeaveBalance[]>(
    ['leave','balances',employeeId,year],
    `/api/leave/balances/${employeeId}${year?`?year=${year}`:''}`,
    { enabled: !!employeeId }
  );
}
export function usePublicHolidays(year?: number) {
  return useApi<PublicHoliday[]>(['leave','holidays',year], `/api/leave/holidays${year?`?year=${year}`:''}` );
}
export function useLeaveCalendar(month: number, year: number) {
  return useApi<{leaves:any[];holidays:PublicHoliday[]}>(
    ['leave','calendar',month,year], `/api/leave/calendar?month=${month}&year=${year}`
  );
}
export function useInitialiseLeaveBalances() {
  return useApiMutation('/api/leave/balances/initialise','POST',[['leave','balances']]);
}

// ── Visa Management ───────────────────────────────────────────────────────────
export interface VisaRecord {
  id:                string;
  employee_id:       string;
  employee_name:     string;
  employee_email:    string;
  visa_type:         string;
  visa_number?:      string;
  country_of_issue:  string;
  issue_date?:       string;
  expiry_date?:      string;
  days_remaining?:   number;
  status:            string;
  sponsorship_required: number;
  sponsor_licence_number?: string;
  cos_number?:       string;
  cos_expiry?:       string;
  notes?:            string;
  created_at:        string;
}

export function useVisas(params?: Record<string,string>) {
  const qs = params ? '?'+new URLSearchParams(params).toString() : '';
  return useApi<VisaRecord[]>(['visas',params], `/api/visas${qs}`);
}
export function useCreateVisa() {
  return useApiMutation('/api/visas','POST',[['visas']]);
}
export function useUpdateVisa(id: string) {
  return useApiMutation(`/api/visas/${id}`,'PATCH',[['visas']]);
}

// ── Dashboard ─────────────────────────────────────────────────────────────────
export interface DashboardMetrics {
  employees:        { total:number; active:number; on_leave:number; new_this_month:number };
  leave:            { pending:number; approved_today:number; on_leave_now:number };
  timesheets:       { pending:number; missing:number; submitted_this_week:number };
  expenses:         { pending:number; pending_value:number };
  compliance:       { expired:number; expiring_90:number };
  visas:            { expiring_90:number; expiring_30:number };
  recruitment:      { open_roles:number; candidates:number };
  projects:         { active:number; tasks_overdue:number };
  onboarding:       { active:number };
  workflows:        { pending:number; escalated:number };
}
export interface ActivityItem {
  id:string; action:string; resource:string; user_email:string; created_at:string; resource_id:string;
}

export function useDashboardMetrics() {
  return useApi<DashboardMetrics>(['dashboard','metrics'], '/api/dashboard/metrics', { refetchInterval: 60_000 });
}
export function useDashboardActivity() {
  return useApi<ActivityItem[]>(['dashboard','activity'], '/api/dashboard/activity');
}

// ── Reporting ─────────────────────────────────────────────────────────────────
export interface HeadcountTrend   { month:string; total:number; active:number; new_hires:number; leavers:number }
export interface LeaveReport      { leave_type:string; total_days:number; employee_count:number; avg_days:number }
export interface TimesheetReport  { employee_name:string; total_hours:number; billable_hours:number; utilisation:number; submitted:number; approved:number }
export interface ComplianceReport { category:string; total:number; compliant:number; expiring:number; expired:number; compliance_pct:number }
export interface ProjectReport    { name:string; status:string; budget:number; spent:number; budget_pct:number; task_count:number; done_count:number; completion_pct:number }

export function useHeadcountReport()   { return useApi<HeadcountTrend[]>  (['reports','headcount'],   '/api/reports/headcount'); }
export function useLeaveReport(year?:number)        { return useApi<LeaveReport[]>    (['reports','leave',year],   `/api/reports/leave${year?`?year=${year}`:''}`);}
export function useTimesheetReport(params?:Record<string,string>) {
  const qs = params?'?'+new URLSearchParams(params).toString():'';
  return useApi<TimesheetReport[]>(['reports','timesheets',params], `/api/reports/timesheets${qs}`);
}
export function useComplianceReport()  { return useApi<ComplianceReport[]>(['reports','compliance'],  '/api/reports/compliance'); }
export function useProjectReport()     { return useApi<ProjectReport[]>   (['reports','projects'],    '/api/reports/projects'); }

// ── Notifications ─────────────────────────────────────────────────────────────
export interface Notification {
  id:string; type:string; title:string; body:string; link?:string;
  read:number; created_at:string; priority:'low'|'medium'|'high';
}
export function useNotifications() {
  return useApi<Notification[]>(['notifications'], '/api/notifications', { refetchInterval: 30_000 });
}
export function useMarkNotificationRead() {
  return useApiMutation('/api/notifications/read','POST',[['notifications']]);
}

// ── Dashboard (live) ──────────────────────────────────────────────────────────
export interface DashboardMetrics {
  activeEmployees:       number;
  onLeaveToday:          number;
  pendingLeave:          number;
  pendingTimesheets:     number;
  pendingExpenses:       number;
  openJobs:              number;
  activeProjects:        number;
  expiringRTW:           number;
  expiringVisas:         number;
  overdueOnboarding:     number;
  totalPendingApprovals: number;
}
export interface Notification {
  id:         string;
  type:       string;
  icon:       string;
  title:      string;
  link:       string;
  priority:   string;
  created_at: string;
}
export function useLiveDashboard() {
  return useApi<{ metrics: DashboardMetrics; recentActivity: any[] }>(
    ['dashboard','live'], '/api/dashboard', { refetchInterval: 30_000 }
  );
}
export function useNotifications() {
  return useApi<Notification[]>(['dashboard','notifications'], '/api/dashboard/notifications', { refetchInterval: 30_000 });
}

// ── Reporting ─────────────────────────────────────────────────────────────────
export function useHeadcountReport() {
  return useApi<any>(['reporting','headcount'], '/api/reporting/headcount');
}
export function useLeaveReport() {
  return useApi<any>(['reporting','leave'], '/api/reporting/leave');
}
export function useTimesheetReport() {
  return useApi<any>(['reporting','timesheets'], '/api/reporting/timesheets');
}
export function useComplianceReport() {
  return useApi<any>(['reporting','compliance'], '/api/reporting/compliance');
}
export function useProjectReport() {
  return useApi<any>(['reporting','projects'], '/api/reporting/projects');
}
