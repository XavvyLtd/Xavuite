export default {
  key:'reporting', title:'Reports', icon:'📊', group:'admin',
  permissions:[], navigation:[{ label:'Analytics', path:'/reporting', permission:null }],
};
