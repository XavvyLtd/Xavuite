import { ok } from '../../core/response';
import type { Env, AppContext } from '../../types';

export async function handleReporting(
  request: Request, env: Env, ctx: AppContext, subPath: string
): Promise<Response> {
  const [resource] = subPath.split('/').filter(Boolean);
  const tid = ctx.tenantId;

  // GET /api/reporting/headcount
  if (resource === 'headcount') {
    const [byDept, byType, byLocation, monthly] = await Promise.all([
      env.DB.prepare(`
        SELECT d.name, COUNT(e.id) as count
        FROM employees e
        JOIN employee_history eh ON eh.employee_id=e.id AND eh.is_current=1
        LEFT JOIN departments d ON d.id=eh.department_id
        WHERE e.tenant_id=? AND e.status='active'
        GROUP BY d.name ORDER BY count DESC
      `).bind(tid).all(),
      env.DB.prepare(`
        SELECT eh.employment_type, COUNT(e.id) as count
        FROM employees e
        JOIN employee_history eh ON eh.employee_id=e.id AND eh.is_current=1
        WHERE e.tenant_id=? AND e.status='active'
        GROUP BY eh.employment_type ORDER BY count DESC
      `).bind(tid).all(),
      env.DB.prepare(`
        SELECT eh.work_location_type, COUNT(e.id) as count
        FROM employees e
        JOIN employee_history eh ON eh.employee_id=e.id AND eh.is_current=1
        WHERE e.tenant_id=? AND e.status='active'
        GROUP BY eh.work_location_type ORDER BY count DESC
      `).bind(tid).all(),
      env.DB.prepare(`
        SELECT strftime('%Y-%m', e.created_at) as month, COUNT(*) as new_hires
        FROM employees e WHERE e.tenant_id=? AND e.created_at>=date('now','-12 months')
        GROUP BY month ORDER BY month
      `).bind(tid).all(),
    ]);
    return ok({ byDept: byDept.results, byType: byType.results, byLocation: byLocation.results, monthly: monthly.results });
  }

  // GET /api/reporting/leave
  if (resource === 'leave') {
    const [byType, byMonth, topTakers, avgDuration] = await Promise.all([
      env.DB.prepare(`
        SELECT leave_type, COUNT(*) as requests, SUM(days) as total_days
        FROM leave_requests WHERE tenant_id=? AND status='approved' AND start_date>=date('now','-12 months')
        GROUP BY leave_type ORDER BY total_days DESC
      `).bind(tid).all(),
      env.DB.prepare(`
        SELECT strftime('%Y-%m', start_date) as month, COUNT(*) as requests, SUM(days) as days
        FROM leave_requests WHERE tenant_id=? AND status='approved' AND start_date>=date('now','-12 months')
        GROUP BY month ORDER BY month
      `).bind(tid).all(),
      env.DB.prepare(`
        SELECT eh.first_name||' '||eh.last_name as name, COUNT(*) as requests, SUM(lr.days) as days
        FROM leave_requests lr
        JOIN employees e ON e.id=lr.employee_id
        JOIN employee_history eh ON eh.employee_id=e.id AND eh.is_current=1
        WHERE lr.tenant_id=? AND lr.status='approved' AND lr.start_date>=date('now','-12 months')
        GROUP BY lr.employee_id ORDER BY days DESC LIMIT 10
      `).bind(tid).all(),
      env.DB.prepare(`
        SELECT AVG(days) as avg_duration FROM leave_requests
        WHERE tenant_id=? AND status='approved' AND start_date>=date('now','-12 months')
      `).bind(tid).first(),
    ]);
    return ok({ byType: byType.results, byMonth: byMonth.results, topTakers: topTakers.results, avgDuration });
  }

  // GET /api/reporting/timesheets
  if (resource === 'timesheets') {
    const [weekly, utilisation, byEmployee, missing] = await Promise.all([
      env.DB.prepare(`
        SELECT week_starting, SUM(total_hours) as hours, SUM(billable_hours) as billable,
               ROUND(SUM(billable_hours)*100.0/NULLIF(SUM(total_hours),0),1) as util_pct
        FROM timesheets WHERE tenant_id=? AND status='approved' AND week_starting>=date('now','-13 weeks')
        GROUP BY week_starting ORDER BY week_starting
      `).bind(tid).all(),
      env.DB.prepare(`
        SELECT eh.first_name||' '||eh.last_name as name,
               ROUND(AVG(t.billable_hours)*100.0/NULLIF(AVG(t.total_hours),0),1) as util_pct,
               SUM(t.total_hours) as total_hours, SUM(t.billable_hours) as billable_hours
        FROM timesheets t
        JOIN employees e ON e.id=t.employee_id
        JOIN employee_history eh ON eh.employee_id=e.id AND eh.is_current=1
        WHERE t.tenant_id=? AND t.status='approved' AND t.week_starting>=date('now','-13 weeks')
        GROUP BY t.employee_id ORDER BY util_pct DESC
      `).bind(tid).all(),
      env.DB.prepare(`
        SELECT eh.first_name||' '||eh.last_name as name,
               COUNT(*) as submissions, SUM(t.total_hours) as hours
        FROM timesheets t
        JOIN employees e ON e.id=t.employee_id
        JOIN employee_history eh ON eh.employee_id=e.id AND eh.is_current=1
        WHERE t.tenant_id=? AND t.week_starting>=date('now','-13 weeks')
        GROUP BY t.employee_id ORDER BY hours DESC
      `).bind(tid).all(),
      env.DB.prepare(`
        SELECT eh.first_name||' '||eh.last_name as name, u.email
        FROM employees e
        JOIN employee_history eh ON eh.employee_id=e.id AND eh.is_current=1
        JOIN users u ON u.id=e.user_id
        WHERE e.tenant_id=? AND e.status='active'
          AND e.id NOT IN (SELECT employee_id FROM timesheets WHERE tenant_id=? AND week_starting=date('now','weekday 1','-7 days'))
      `).bind(tid, tid).all(),
    ]);
    return ok({ weekly: weekly.results, utilisation: utilisation.results, byEmployee: byEmployee.results, missing: missing.results });
  }

  // GET /api/reporting/compliance
  if (resource === 'compliance') {
    const [rtwSummary, visaSummary, trainingCompliance, onboardingStatus] = await Promise.all([
      env.DB.prepare(`
        SELECT
          COUNT(*) as total,
          SUM(CASE WHEN status='valid' THEN 1 ELSE 0 END) as valid,
          SUM(CASE WHEN status='expired' THEN 1 ELSE 0 END) as expired,
          SUM(CASE WHEN expiry_date IS NOT NULL AND expiry_date<=date('now','+90 days') AND expiry_date>=date('now') THEN 1 ELSE 0 END) as expiring
        FROM employee_right_to_work WHERE tenant_id=?
      `).bind(tid).first(),
      env.DB.prepare(`
        SELECT
          COUNT(*) as total,
          SUM(CASE WHEN status='active' THEN 1 ELSE 0 END) as active,
          SUM(CASE WHEN status='expired' THEN 1 ELSE 0 END) as expired,
          SUM(CASE WHEN expiry_date<=date('now','+30 days') AND expiry_date>=date('now') THEN 1 ELSE 0 END) as expiring30,
          SUM(CASE WHEN sponsorship_required=1 THEN 1 ELSE 0 END) as sponsored
        FROM employee_visas WHERE tenant_id=?
      `).bind(tid).first(),
      env.DB.prepare(`
        SELECT
          COUNT(*) as total,
          SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as completed,
          SUM(CASE WHEN mandatory=1 AND status!='completed' THEN 1 ELSE 0 END) as mandatory_incomplete
        FROM training_assignments WHERE tenant_id=?
      `).bind(tid).first(),
      env.DB.prepare(`
        SELECT status, COUNT(*) as count FROM employee_onboarding WHERE tenant_id=? GROUP BY status
      `).bind(tid).all(),
    ]);
    return ok({ rtwSummary, visaSummary, trainingCompliance, onboardingStatus: onboardingStatus.results });
  }

  // GET /api/reporting/projects
  if (resource === 'projects') {
    const [summary, taskStatus, budgetUsage, teamUtil] = await Promise.all([
      env.DB.prepare(`
        SELECT status, COUNT(*) as count, SUM(budget) as budget, SUM(spent) as spent
        FROM pmo_projects WHERE tenant_id=? GROUP BY status
      `).bind(tid).all(),
      env.DB.prepare(`
        SELECT status, COUNT(*) as count FROM pmo_tasks WHERE tenant_id=? GROUP BY status ORDER BY count DESC
      `).bind(tid).all(),
      env.DB.prepare(`
        SELECT name, budget, spent, ROUND(spent*100.0/NULLIF(budget,0),1) as pct_used
        FROM pmo_projects WHERE tenant_id=? AND budget>0 AND status='active' ORDER BY pct_used DESC LIMIT 10
      `).bind(tid).all(),
      env.DB.prepare(`
        SELECT eh.first_name||' '||eh.last_name as name,
               COUNT(DISTINCT pa.project_id) as projects,
               SUM(pa.allocation) as total_allocation
        FROM pmo_allocations pa
        JOIN employees e ON e.id=pa.employee_id
        JOIN employee_history eh ON eh.employee_id=e.id AND eh.is_current=1
        WHERE pa.tenant_id=? AND (pa.end_date IS NULL OR pa.end_date>=date('now'))
        GROUP BY pa.employee_id ORDER BY total_allocation DESC
      `).bind(tid).all(),
    ]);
    return ok({ summary: summary.results, taskStatus: taskStatus.results, budgetUsage: budgetUsage.results, teamUtil: teamUtil.results });
  }

  return ok({});
}
