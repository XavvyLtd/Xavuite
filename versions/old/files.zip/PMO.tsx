import { useState } from 'react';
import {
  useProjects, useCreateProject, useTasks, useCreateTask, useUpdateTask,
  useSprints, useEmployees, type Project, type Task
} from '../../hooks/api';
import {
  Card, DataTable, SectionHeader, Tabs, Btn, Avatar, StatusBadge,
  Modal, InfoRow, MetricCard, MetricGrid, ProgressBar, Loading,
  Alert, FormField, inputStyle, selectStyle, C, fmtDate, ColDef
} from '../../components/ui';

// ── Add Project Form ──────────────────────────────────────────────────────────
function AddProjectModal({ onClose }: { onClose: () => void }) {
  const create = useCreateProject();
  const [errMsg, setErrMsg] = useState('');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: '', clientName: '', startDate: '', endDate: '',
    budget: '', priority: 'medium', status: 'planning',
  });
  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.name.trim()) { setErrMsg('Project name is required'); return; }
    setSaving(true); setErrMsg('');
    try {
      await create.mutateAsync({
        ...form,
        budget: form.budget ? Number(form.budget) : undefined,
      });
      onClose();
    }
    catch (e: any) { setErrMsg(e.message ?? 'Failed to create project'); }
    finally { setSaving(false); }
  };

  return (
    <Modal title="New Project" onClose={onClose} wide>
      {errMsg && <Alert type="error" message={errMsg} />}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
        <FormField label="Project Name" required>
          <input style={inputStyle} placeholder="e.g. IoT Platform v2" value={form.name} onChange={e => set('name', e.target.value)} />
        </FormField>
        <FormField label="Client Name">
          <input style={inputStyle} placeholder="e.g. Xavvy Ltd" value={form.clientName} onChange={e => set('clientName', e.target.value)} />
        </FormField>
        <FormField label="Start Date">
          <input style={inputStyle} type="date" value={form.startDate} onChange={e => set('startDate', e.target.value)} />
        </FormField>
        <FormField label="End Date">
          <input style={inputStyle} type="date" value={form.endDate} onChange={e => set('endDate', e.target.value)} />
        </FormField>
        <FormField label="Budget (£)">
          <input style={inputStyle} type="number" min="0" placeholder="0" value={form.budget} onChange={e => set('budget', e.target.value)} />
        </FormField>
        <FormField label="Priority">
          <select style={selectStyle} value={form.priority} onChange={e => set('priority', e.target.value)}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="critical">Critical</option>
          </select>
        </FormField>
        <FormField label="Status">
          <select style={selectStyle} value={form.status} onChange={e => set('status', e.target.value)}>
            <option value="planning">Planning</option>
            <option value="active">Active</option>
            <option value="on_hold">On Hold</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </FormField>
      </div>
      <div style={{ display:'flex', justifyContent:'flex-end', gap:8, marginTop:24 }}>
        <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
        <Btn onClick={handleSave} disabled={saving}>{saving ? 'Creating...' : '+ Create Project'}</Btn>
      </div>
    </Modal>
  );
}

// ── Add Task Form ─────────────────────────────────────────────────────────────
function AddTaskModal({ onClose, projects }: { onClose: () => void; projects: Project[] }) {
  const create = useCreateTask();
  const { data: employees } = useEmployees();
  const { data: sprints } = useSprints();
  const [errMsg, setErrMsg] = useState('');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    projectId: projects[0]?.id ?? '',
    sprintId: '', name: '', description: '',
    assigneeId: '', priority: 'medium', status: 'backlog',
    estimatedHours: '8', dueDate: '',
  });
  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.name.trim() || !form.projectId) { setErrMsg('Project and task name are required'); return; }
    setSaving(true); setErrMsg('');
    try {
      await create.mutateAsync({
        ...form,
        estimatedHours: form.estimatedHours ? Number(form.estimatedHours) : undefined,
        sprintId: form.sprintId || undefined,
        assigneeId: form.assigneeId || undefined,
        dueDate: form.dueDate || undefined,
      });
      onClose();
    }
    catch (e: any) { setErrMsg(e.message ?? 'Failed to create task'); }
    finally { setSaving(false); }
  };

  const projectSprints = (sprints ?? []).filter((s: any) => s.project_id === form.projectId);

  return (
    <Modal title="New Task" onClose={onClose} wide>
      {errMsg && <Alert type="error" message={errMsg} />}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
        <FormField label="Project" required>
          <select style={selectStyle} value={form.projectId} onChange={e => set('projectId', e.target.value)}>
            {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </FormField>
        <FormField label="Phase / Sprint">
          <select style={selectStyle} value={form.sprintId} onChange={e => set('sprintId', e.target.value)}>
            <option value="">No sprint</option>
            {projectSprints.map((s: any) => <option key={s.id} value={s.id}>{s.sprint_name}</option>)}
          </select>
        </FormField>
      </div>
      <FormField label="Task Name" required>
        <input style={inputStyle} placeholder="e.g. Build RTW API endpoints" value={form.name} onChange={e => set('name', e.target.value)} />
      </FormField>
      <FormField label="Description">
        <textarea style={{ ...inputStyle, height: 72, resize:'vertical' }} placeholder="Optional detail..." value={form.description} onChange={e => set('description', e.target.value)} />
      </FormField>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr', gap:12 }}>
        <FormField label="Assignee">
          <select style={selectStyle} value={form.assigneeId} onChange={e => set('assigneeId', e.target.value)}>
            <option value="">Unassigned</option>
            {(employees?.items ?? []).map(e => <option key={e.id} value={e.id}>{e.first_name} {e.last_name}</option>)}
          </select>
        </FormField>
        <FormField label="Priority">
          <select style={selectStyle} value={form.priority} onChange={e => set('priority', e.target.value)}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="critical">Critical</option>
          </select>
        </FormField>
        <FormField label="Status">
          <select style={selectStyle} value={form.status} onChange={e => set('status', e.target.value)}>
            <option value="backlog">Backlog</option>
            <option value="todo">To Do</option>
            <option value="in_progress">In Progress</option>
            <option value="review">Review</option>
            <option value="done">Done</option>
          </select>
        </FormField>
        <FormField label="Est. Hours">
          <input style={inputStyle} type="number" min="1" value={form.estimatedHours} onChange={e => set('estimatedHours', e.target.value)} />
        </FormField>
      </div>
      <FormField label="Due Date">
        <input style={inputStyle} type="date" value={form.dueDate} onChange={e => set('dueDate', e.target.value)} />
      </FormField>
      <div style={{ display:'flex', justifyContent:'flex-end', gap:8, marginTop:24 }}>
        <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
        <Btn onClick={handleSave} disabled={saving}>{saving ? 'Creating...' : '+ Create Task'}</Btn>
      </div>
    </Modal>
  );
}

// ── Edit Task Modal ───────────────────────────────────────────────────────────
function EditTaskModal({ task, onClose }: { task: Task; onClose: () => void }) {
  const update = useUpdateTask(task.id);
  const { data: employees } = useEmployees();
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: task.name,
    status: task.status,
    priority: task.priority,
    assignee_id: task.assignee_id ?? '',
    estimated_hours: task.estimated_hours ?? 8,
  });
  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    setSaving(true);
    try { await update.mutateAsync({ ...form, assignee_id: form.assignee_id || null }); onClose(); }
    catch (e: any) { alert(e.message); }
    finally { setSaving(false); }
  };

  return (
    <Modal title="Edit Task" onClose={onClose}>
      <FormField label="Task Name">
        <input style={inputStyle} value={form.name} onChange={e => set('name', e.target.value)} />
      </FormField>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
        <FormField label="Status">
          <select style={selectStyle} value={form.status} onChange={e => set('status', e.target.value)}>
            <option value="backlog">Backlog</option>
            <option value="todo">To Do</option>
            <option value="in_progress">In Progress</option>
            <option value="review">Review</option>
            <option value="done">Done</option>
          </select>
        </FormField>
        <FormField label="Priority">
          <select style={selectStyle} value={form.priority} onChange={e => set('priority', e.target.value)}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="critical">Critical</option>
          </select>
        </FormField>
        <FormField label="Assignee">
          <select style={selectStyle} value={form.assignee_id} onChange={e => set('assignee_id', e.target.value)}>
            <option value="">Unassigned</option>
            {(employees?.items ?? []).map(e => <option key={e.id} value={e.id}>{e.first_name} {e.last_name}</option>)}
          </select>
        </FormField>
        <FormField label="Est. Hours">
          <input style={inputStyle} type="number" min="1" value={form.estimated_hours} onChange={e => set('estimated_hours', Number(e.target.value))} />
        </FormField>
      </div>
      <div style={{ display:'flex', justifyContent:'flex-end', gap:8, marginTop:24 }}>
        <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
        <Btn onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Save Changes'}</Btn>
      </div>
    </Modal>
  );
}

// ── Main PMO Module ───────────────────────────────────────────────────────────
const KANBAN_COLS = ['backlog','todo','in_progress','review','done'] as const;
const COL_LABELS: Record<string, string> = { backlog:'Backlog', todo:'To Do', in_progress:'In Progress', review:'Review', done:'Done' };
const COL_COLORS: Record<string, string> = { backlog:C.dim, todo:C.muted, in_progress:C.amber, review:C.sky, done:C.green };

export default function PMOModule() {
  const [view, setView]               = useState<'projects'|'board'>('projects');
  const [projectFilter, setProjectFilter] = useState('');
  const [selected, setSelected]       = useState<Project | null>(null);
  const [editTask, setEditTask]       = useState<Task | null>(null);
  const [showAddProject, setShowAddProject] = useState(false);
  const [showAddTask, setShowAddTask] = useState(false);

  const { data: projects, isLoading: pLoading, refetch: refetchProjects } = useProjects();
  const { data: tasks,    isLoading: tLoading, refetch: refetchTasks }    = useTasks(projectFilter ? { projectId: projectFilter } : {});

  const allProjects = projects ?? [];
  const active      = allProjects.filter(p => p.status === 'active');
  const totalBudget = allProjects.reduce((a, p) => a + (p.budget ?? 0), 0);
  const totalSpent  = allProjects.reduce((a, p) => a + (p.spent  ?? 0), 0);

  return (
    <div className="animate-fadeIn">
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom:20 }}>
        <div><h2 style={{color:'#F1F5F9',fontSize:20,fontWeight:800,margin:0}}>Projects & Tasks</h2><p style={{color:'#94A3B8',fontSize:12,margin:'4px 0 0'}}>{active.length} active · {allProjects.length} total</p></div>
        <div style={{display:'flex',gap:8}}>
          <button onClick={() => setShowAddTask(true)} style={{background:'transparent',color:'#94A3B8',border:'1px solid #1E293B',borderRadius:8,padding:'8px 18px',fontSize:13,fontWeight:700,cursor:'pointer'}}>+ Task</button>
          <button onClick={() => setShowAddProject(true)} style={{background:'#6366F1',color:'#fff',border:'none',borderRadius:8,padding:'8px 18px',fontSize:13,fontWeight:700,cursor:'pointer'}}>+ Project</button>
        </div>
      </div>

      <MetricGrid>
        <MetricCard label="Active"     value={active.length}                        icon="📂" color={`linear-gradient(135deg,${C.accent},${C.purple})`} />
        <MetricCard label="Budget"     value={`£${(totalBudget/1000).toFixed(0)}k`} icon="💷" color={`linear-gradient(135deg,${C.teal},${C.sky})`} />
        <MetricCard label="Spent"      value={`£${(totalSpent/1000).toFixed(0)}k`}  icon="💸" color={`linear-gradient(135deg,${C.amber},${C.red})`} />
        <MetricCard label="Open Tasks" value={(tasks ?? []).filter(t=>t.status!=='done').length} icon="✅" color={`linear-gradient(135deg,${C.green},${C.teal})`} />
      </MetricGrid>

      <Tabs tabs={[{key:'projects',label:'📂 Projects'},{key:'board',label:'📋 Task Board'}]} active={view} onChange={v => setView(v as any)} />

      {/* PROJECTS VIEW */}
      {view === 'projects' && (
        pLoading ? <Loading /> : (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(300px,1fr))', gap:16 }}>
            {allProjects.map(p => {
              const pct = p.budget && p.budget > 0 ? Math.round(((p.spent ?? 0) / p.budget) * 100) : 0;
              return (
                <Card key={p.id} onClick={() => setSelected(p)} style={{ cursor:'pointer' }}>
                  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:10 }}>
                    <div style={{ fontWeight:800, color:C.text, fontSize:14 }}>{p.name}</div>
                    <StatusBadge status={p.priority} />
                  </div>
                  <ProgressBar value={pct} color={pct > 90 ? C.red : pct > 70 ? C.amber : C.green} />
                  <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, color:C.muted, marginTop:4, marginBottom:10 }}>
                    <span>{pct}% budget used</span>
                    <span>{p.task_count ?? 0} tasks · {p.team_size ?? 0} people</span>
                  </div>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', paddingTop:10, borderTop:`1px solid ${C.border}33` }}>
                    <StatusBadge status={p.status} />
                    {p.end_date && <span style={{fontSize:11,color:C.muted}}>Due {fmtDate(p.end_date)}</span>}
                  </div>
                </Card>
              );
            })}
            {/* Add new project card */}
            <div onClick={() => setShowAddProject(true)} style={{
              border: `2px dashed ${C.border}`, borderRadius:16, padding:20, cursor:'pointer',
              display:'flex', alignItems:'center', justifyContent:'center', gap:8,
              color:C.textMuted, fontSize:13, fontWeight:600, transition:'border-color 0.15s',
              minHeight: 140,
            }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = C.accent)}
              onMouseLeave={e => (e.currentTarget.style.borderColor = C.border)}
            >
              <span style={{fontSize:20}}>+</span> New Project
            </div>
          </div>
        )
      )}

      {/* BOARD VIEW */}
      {view === 'board' && (
        <div>
          <div style={{ marginBottom:16, display:'flex', alignItems:'center', gap:12 }}>
            <select value={projectFilter} onChange={e => setProjectFilter(e.target.value)}
              style={{ background:C.elevated, border:`1px solid ${C.border}`, borderRadius:8, padding:'8px 12px', color:C.text, fontSize:13, outline:'none' }}>
              <option value="">All projects</option>
              {allProjects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <Btn small onClick={() => setShowAddTask(true)}>+ Add Task</Btn>
          </div>

          {tLoading ? <Loading /> : (
            <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:12, overflowX:'auto' }}>
              {KANBAN_COLS.map(col => {
                const colTasks = (tasks ?? []).filter(t => t.status === col);
                return (
                  <div key={col}>
                    <div style={{ display:'flex', justifyContent:'space-between', marginBottom:10, padding:'0 2px' }}>
                      <span style={{ fontSize:11, fontWeight:700, color:COL_COLORS[col], textTransform:'uppercase', letterSpacing:'0.05em' }}>{COL_LABELS[col]}</span>
                      <span style={{ background:COL_COLORS[col]+'22', color:COL_COLORS[col], borderRadius:4, fontSize:10, padding:'2px 6px', fontWeight:700 }}>{colTasks.length}</span>
                    </div>
                    <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
                      {colTasks.map(task => (
                        <div key={task.id} onClick={() => setEditTask(task)} style={{
                          background:C.card, border:`1px solid ${C.border}`, borderRadius:10, padding:12,
                          cursor:'pointer', transition:'border-color 0.15s'
                        }}
                          onMouseEnter={e => (e.currentTarget.style.borderColor = C.accent+'55')}
                          onMouseLeave={e => (e.currentTarget.style.borderColor = C.border)}
                        >
                          <div style={{ fontSize:12, fontWeight:700, color:C.text, marginBottom:8, lineHeight:1.4 }}>{task.name}</div>
                          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                            {task.assignee_name ? <Avatar name={task.assignee_name} size={22}/> : <span style={{fontSize:10,color:C.dim}}>Unassigned</span>}
                            <StatusBadge status={task.priority} />
                          </div>
                          {task.estimated_hours && <div style={{fontSize:10,color:C.dim,marginTop:6}}>{task.estimated_hours}h estimated</div>}
                          {task.due_date && <div style={{fontSize:10,color:C.amber,marginTop:2}}>Due {fmtDate(task.due_date)}</div>}
                        </div>
                      ))}
                      {colTasks.length === 0 && (
                        <div style={{ border:`1.5px dashed ${C.border}`, borderRadius:10, padding:'20px 12px', textAlign:'center', color:C.dim, fontSize:11 }}>Empty</div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Modals */}
      {showAddProject && <AddProjectModal onClose={() => { setShowAddProject(false); refetchProjects(); }} />}
      {showAddTask    && <AddTaskModal    onClose={() => { setShowAddTask(false); refetchTasks(); }} projects={allProjects} />}
      {editTask       && <EditTaskModal   task={editTask} onClose={() => { setEditTask(null); refetchTasks(); }} />}

      {selected && (
        <Modal title={selected.name} onClose={() => setSelected(null)}>
          <InfoRow label="Status"   value={<StatusBadge status={selected.status} />} />
          <InfoRow label="Priority" value={<StatusBadge status={selected.priority} />} />
          {selected.end_date && <InfoRow label="Deadline" value={fmtDate(selected.end_date)} />}
          {selected.budget && <InfoRow label="Budget"  value={`£${Number(selected.budget).toLocaleString()}`} />}
          {selected.budget && <InfoRow label="Spent"   value={`£${Number(selected.spent ?? 0).toLocaleString()} (${Math.round(Number(selected.spent ?? 0)/Number(selected.budget)*100)}%)`} />}
          <InfoRow label="Tasks"  value={selected.task_count ?? 0} />
          <InfoRow label="Team"   value={`${selected.team_size ?? 0} members`} />
          <div style={{ marginTop:16, display:'flex', gap:8 }}>
            <Btn small onClick={() => { setSelected(null); setProjectFilter(selected.id); setView('board'); }}>View Board →</Btn>
            <Btn small variant="ghost" onClick={() => setSelected(null)}>Close</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}
