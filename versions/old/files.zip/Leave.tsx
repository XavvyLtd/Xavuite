import { useState } from 'react';
import {
  useLeaveRequests, useLeaveDecision, useCreateLeave,
  useTimesheets, useTimesheetDecision, useBulkTimesheetDecision, useSubmitTimesheet,
  useExpenses, useExpenseDecision, useCreateExpense,
  useCompliance, useCreateRTW,
  useEmployees,
  type LeaveRequest, type Timesheet, type ExpenseClaim, type RTWCheck
} from '../../hooks/api';
import {
  Card, DataTable, SectionHeader, Tabs, Btn, Avatar, StatusBadge,
  Modal, InfoRow, MetricCard, MetricGrid, Loading, Alert,
  FormField, inputStyle, selectStyle, C, fmtDate, ColDef
} from '../../components/ui';

// ── Shared form save button row ───────────────────────────────────────────────
function FormActions({ onCancel, onSave, saving, saveLabel = 'Save' }: {
  onCancel: () => void; onSave: () => void; saving: boolean; saveLabel?: string;
}) {
  return (
    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 24 }}>
      <Btn variant="ghost" onClick={onCancel}>Cancel</Btn>
      <Btn onClick={onSave} disabled={saving}>{saving ? 'Saving...' : saveLabel}</Btn>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// LEAVE
// ════════════════════════════════════════════════════════════════════════════
function AddLeaveModal({ onClose }: { onClose: () => void }) {
  const create = useCreateLeave();
  const [err, setErr] = useState('');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    leaveType: 'annual', startDate: '', endDate: '', reason: '', halfDay: false,
  });
  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.startDate || !form.endDate) { setErr('Start and end date are required'); return; }
    if (new Date(form.endDate) < new Date(form.startDate)) { setErr('End date must be after start date'); return; }
    setSaving(true); setErr('');
    try { await create.mutateAsync(form); onClose(); }
    catch (e: any) { setErr(e.message ?? 'Failed to submit leave request'); }
    finally { setSaving(false); }
  };

  return (
    <Modal title="Request Leave" onClose={onClose}>
      {err && <Alert type="error" message={err} />}
      <FormField label="Leave Type" required>
        <select style={selectStyle} value={form.leaveType} onChange={e => set('leaveType', e.target.value)}>
          <option value="annual">Annual Leave</option>
          <option value="sick">Sick Leave</option>
          <option value="maternity">Maternity Leave</option>
          <option value="paternity">Paternity Leave</option>
          <option value="compassionate">Compassionate Leave</option>
          <option value="unpaid">Unpaid Leave</option>
          <option value="other">Other</option>
        </select>
      </FormField>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <FormField label="From" required>
          <input style={inputStyle} type="date" value={form.startDate} onChange={e => set('startDate', e.target.value)} />
        </FormField>
        <FormField label="To" required>
          <input style={inputStyle} type="date" value={form.endDate} onChange={e => set('endDate', e.target.value)} />
        </FormField>
      </div>
      <FormField label="Reason">
        <textarea style={{ ...inputStyle, height: 80, resize: 'vertical' }} value={form.reason} onChange={e => set('reason', e.target.value)} placeholder="Optional reason..." />
      </FormField>
      <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: C.muted, cursor: 'pointer' }}>
        <input type="checkbox" checked={form.halfDay} onChange={e => set('halfDay', e.target.checked)} />
        Half day
      </label>
      <FormActions onCancel={onClose} onSave={handleSave} saving={saving} saveLabel="Submit Request" />
    </Modal>
  );
}

export function LeaveModule() {
  const [tab, setTab] = useState('all');
  const [selected, setSelected] = useState<LeaveRequest | null>(null);
  const [showAdd, setShowAdd] = useState(false);

  const params = tab === 'mine' ? { mine: 'true' } : tab === 'pending' ? { status: 'pending' } : {};
  const { data: leaves, isLoading, refetch } = useLeaveRequests(params);
  const decision = useLeaveDecision(selected?.id ?? '');

  const items = leaves ?? [];
  const pending = items.filter(l => l.status === 'pending');
  const approved = items.filter(l => l.status === 'approved');
  const onLeaveNow = items.filter(l => {
    const now = new Date();
    return l.status === 'approved' && new Date(l.start_date) <= now && new Date(l.end_date) >= now;
  });

  const handleDecision = async (dec: 'approved' | 'declined') => {
    if (!selected) return;
    try { await decision.mutateAsync({ decision: dec }); setSelected(null); refetch(); }
    catch (e: any) { alert(e.message); }
  };

  const cols: ColDef<LeaveRequest>[] = [
    { key: 'employee_name', label: 'Employee', render: v => <div style={{ display:'flex', alignItems:'center', gap:8 }}><Avatar name={v} size={28}/><span style={{fontWeight:600}}>{v}</span></div> },
    { key: 'leave_type', label: 'Type', render: v => v?.replace(/_/g, ' ') },
    { key: 'start_date', label: 'From', render: v => fmtDate(v) },
    { key: 'end_date', label: 'To', render: v => fmtDate(v) },
    { key: 'days', label: 'Days', muted: true },
    { key: 'status', label: 'Status', render: v => <StatusBadge status={v} /> },
    { key: 'id', label: '', render: (_, r) => r.status === 'pending' ? (
      <div style={{ display:'flex', gap:6 }}>
        <Btn small onClick={e => { (e as any).stopPropagation(); setSelected(r); setTimeout(() => handleDecision('approved'), 0); }}>✓ Approve</Btn>
        <Btn small variant="danger" onClick={e => { (e as any).stopPropagation(); setSelected(r); setTimeout(() => handleDecision('declined'), 0); }}>✗ Decline</Btn>
      </div>
    ) : null },
  ];

  return (
    <div className="animate-fadeIn">
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom:20 }}>
        <div><h2 style={{color:'#F1F5F9',fontSize:20,fontWeight:800,margin:0}}>Leave Management</h2><p style={{color:'#94A3B8',fontSize:12,margin:'4px 0 0'}}>Requests, approvals and team calendar</p></div>
        <button onClick={() => setShowAdd(true)} style={{background:'#6366F1',color:'#fff',border:'none',borderRadius:8,padding:'8px 18px',fontSize:13,fontWeight:700,cursor:'pointer'}}>+ Request Leave</button>
      </div>
      <MetricGrid>
        <MetricCard label="Pending"      value={pending.length}    icon="⏳" color={`linear-gradient(135deg,${C.amber},${C.red})`} />
        <MetricCard label="Approved"     value={approved.length}   icon="✅" color={`linear-gradient(135deg,${C.green},${C.teal})`} />
        <MetricCard label="On Leave Now" value={onLeaveNow.length} icon="🌴" color={`linear-gradient(135deg,${C.sky},${C.accent})`} />
        <MetricCard label="Total"        value={items.length}      icon="📋" color={`linear-gradient(135deg,${C.accent},${C.purple})`} />
      </MetricGrid>
      <Tabs tabs={[{key:'all',label:'All'},{key:'pending',label:`Pending (${pending.length})`},{key:'mine',label:'Mine'}]} active={tab} onChange={setTab} />
      <Card>{isLoading ? <Loading /> : <DataTable cols={cols} rows={items} onRow={setSelected} emptyText="No leave requests" />}</Card>

      {showAdd && <AddLeaveModal onClose={() => { setShowAdd(false); refetch(); }} />}

      {selected && (
        <Modal title="Leave Request" onClose={() => setSelected(null)}>
          <InfoRow label="Employee"  value={selected.employee_name} />
          <InfoRow label="Type"      value={selected.leave_type?.replace(/_/g, ' ')} />
          <InfoRow label="From"      value={fmtDate(selected.start_date)} />
          <InfoRow label="To"        value={fmtDate(selected.end_date)} />
          <InfoRow label="Days"      value={selected.days} />
          <InfoRow label="Reason"    value={selected.reason ?? '—'} />
          <InfoRow label="Status"    value={<StatusBadge status={selected.status} />} />
          {selected.status === 'pending' && (
            <div style={{ marginTop:16, display:'flex', gap:8 }}>
              <Btn onClick={() => handleDecision('approved')} disabled={decision.isPending}>✓ Approve</Btn>
              <Btn variant="danger" onClick={() => handleDecision('declined')} disabled={decision.isPending}>✗ Decline</Btn>
              <Btn variant="ghost" onClick={() => setSelected(null)}>Close</Btn>
            </div>
          )}
        </Modal>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// TIMESHEETS
// ════════════════════════════════════════════════════════════════════════════
function SubmitTimesheetModal({ onClose }: { onClose: () => void }) {
  const submit = useSubmitTimesheet();
  const [err, setErr] = useState('');
  const [saving, setSaving] = useState(false);
  const [weekStarting, setWeekStarting] = useState('');
  const [entries, setEntries] = useState(
    ['Mon','Tue','Wed','Thu','Fri'].map((d, i) => ({ day: d, hours: 7, description: '', billable: true }))
  );

  const setEntry = (i: number, k: string, v: any) =>
    setEntries(es => es.map((e, idx) => idx === i ? { ...e, [k]: v } : e));

  const getDateForDay = (weekStart: string, dayIndex: number) => {
    if (!weekStart) return '';
    const d = new Date(weekStart);
    d.setDate(d.getDate() + dayIndex);
    return d.toISOString().split('T')[0];
  };

  const handleSave = async () => {
    if (!weekStarting) { setErr('Please select the week starting date'); return; }
    setSaving(true); setErr('');
    try {
      await submit.mutateAsync({
        weekStarting,
        entries: entries.map((e, i) => ({
          date: getDateForDay(weekStarting, i),
          hoursWorked: Number(e.hours),
          description: e.description,
          billable: e.billable,
        })).filter(e => e.hoursWorked > 0),
      });
      onClose();
    }
    catch (e: any) { setErr(e.message ?? 'Failed to submit timesheet'); }
    finally { setSaving(false); }
  };

  return (
    <Modal title="Submit Timesheet" onClose={onClose} wide>
      {err && <Alert type="error" message={err} />}
      <FormField label="Week Starting (Monday)" required>
        <input style={inputStyle} type="date" value={weekStarting} onChange={e => setWeekStarting(e.target.value)} />
      </FormField>
      <div style={{ marginTop: 8, marginBottom: 16, fontSize: 12, color: C.muted }}>
        Total: {entries.reduce((a, e) => a + Number(e.hours), 0)}h &nbsp;|&nbsp; Billable: {entries.filter(e => e.billable).reduce((a, e) => a + Number(e.hours), 0)}h
      </div>
      {entries.map((e, i) => (
        <div key={i} style={{ display: 'grid', gridTemplateColumns: '60px 80px 1fr auto', gap: 8, alignItems: 'center', marginBottom: 8 }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: C.muted }}>{e.day}</span>
          <input style={inputStyle} type="number" min="0" max="24" step="0.5" value={e.hours}
            onChange={ev => setEntry(i, 'hours', ev.target.value)} />
          <input style={inputStyle} placeholder="Description (optional)" value={e.description}
            onChange={ev => setEntry(i, 'description', ev.target.value)} />
          <label style={{ display:'flex', alignItems:'center', gap:4, fontSize:11, color:C.muted, cursor:'pointer', whiteSpace:'nowrap' }}>
            <input type="checkbox" checked={e.billable} onChange={ev => setEntry(i, 'billable', ev.target.checked)} />
            Billable
          </label>
        </div>
      ))}
      <FormActions onCancel={onClose} onSave={handleSave} saving={saving} saveLabel="Submit Timesheet" />
    </Modal>
  );
}

export function TimesheetsModule() {
  const [tab, setTab] = useState('all');
  const [selected, setSelected] = useState<Timesheet | null>(null);
  const [showAdd, setShowAdd] = useState(false);

  const params = tab === 'mine' ? { mine: 'true' } : tab === 'pending' ? { status: 'pending' } : {};
  const { data: timesheets, isLoading, refetch } = useTimesheets(params);
  const tsDecision = useTimesheetDecision(selected?.id ?? '');
  const bulkDecision = useBulkTimesheetDecision();

  const items = timesheets ?? [];
  const pending = items.filter(t => t.status === 'pending');
  const totalHours = items.reduce((a, t) => a + (t.total_hours ?? 0), 0);
  const billableHours = items.reduce((a, t) => a + (t.billable_hours ?? 0), 0);

  const handleDecision = async (dec: 'approved' | 'rejected') => {
    if (!selected) return;
    try { await tsDecision.mutateAsync({ decision: dec }); setSelected(null); refetch(); }
    catch (e: any) { alert(e.message); }
  };

  const cols: ColDef<Timesheet>[] = [
    { key: 'employee_name', label: 'Employee', render: v => <div style={{display:'flex',alignItems:'center',gap:8}}><Avatar name={v} size={28}/><span style={{fontWeight:600}}>{v}</span></div> },
    { key: 'week_starting', label: 'Week of', render: v => fmtDate(v) },
    { key: 'total_hours', label: 'Hours', render: v => <span style={{fontWeight:700}}>{v ?? 0}h</span> },
    { key: 'billable_hours', label: 'Billable', render: v => <span style={{color:C.teal,fontWeight:700}}>{v ?? 0}h</span> },
    { key: 'status', label: 'Status', render: v => <StatusBadge status={v} /> },
    { key: 'submitted_at', label: 'Submitted', render: v => fmtDate(v), muted: true },
  ];

  return (
    <div className="animate-fadeIn">
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom:20 }}>
        <div><h2 style={{color:'#F1F5F9',fontSize:20,fontWeight:800,margin:0}}>Timesheets</h2><p style={{color:'#94A3B8',fontSize:12,margin:'4px 0 0'}}>Track and approve team hours</p></div>
        <div style={{display:'flex',gap:8}}>
          {pending.length > 0 && <button onClick={() => bulkDecision.mutateAsync({ ids: pending.map(t => t.id), decision: 'approved' }).then(() => refetch())} disabled={bulkDecision.isPending} style={{background:'#10B981',color:'#fff',border:'none',borderRadius:8,padding:'8px 18px',fontSize:13,fontWeight:700,cursor:'pointer'}}>✓ Approve All ({pending.length})</button>}
          <button onClick={() => setShowAdd(true)} style={{background:'#6366F1',color:'#fff',border:'none',borderRadius:8,padding:'8px 18px',fontSize:13,fontWeight:700,cursor:'pointer'}}>+ Submit Hours</button>
        </div>
      </div>
      <MetricGrid>
        <MetricCard label="Pending"     value={pending.length} icon="⏱" color={`linear-gradient(135deg,${C.amber},${C.red})`} />
        <MetricCard label="Total Hours" value={totalHours}     icon="🕐" color={`linear-gradient(135deg,${C.accent},${C.purple})`} />
        <MetricCard label="Billable"    value={billableHours}  icon="💰" color={`linear-gradient(135deg,${C.teal},${C.sky})`} />
        <MetricCard label="Utilisation" value={totalHours > 0 ? `${Math.round(billableHours/totalHours*100)}%` : '—'} icon="📊" color={`linear-gradient(135deg,${C.purple},${C.accent})`} />
      </MetricGrid>
      <Tabs tabs={[{key:'all',label:'All'},{key:'pending',label:`Pending (${pending.length})`},{key:'mine',label:'Mine'}]} active={tab} onChange={setTab} />
      <Card>{isLoading ? <Loading /> : <DataTable cols={cols} rows={items} onRow={setSelected} emptyText="No timesheets" />}</Card>

      {showAdd && <SubmitTimesheetModal onClose={() => { setShowAdd(false); refetch(); }} />}

      {selected && (
        <Modal title={`Timesheet — ${selected.employee_name}`} onClose={() => setSelected(null)}>
          <InfoRow label="Employee"  value={selected.employee_name} />
          <InfoRow label="Week"      value={fmtDate(selected.week_starting)} />
          <InfoRow label="Hours"     value={`${selected.total_hours ?? 0}h`} />
          <InfoRow label="Billable"  value={`${selected.billable_hours ?? 0}h`} />
          <InfoRow label="Submitted" value={fmtDate(selected.submitted_at)} />
          <InfoRow label="Status"    value={<StatusBadge status={selected.status} />} />
          {selected.status === 'pending' && (
            <div style={{marginTop:16,display:'flex',gap:8}}>
              <Btn onClick={() => handleDecision('approved')} disabled={tsDecision.isPending}>✓ Approve</Btn>
              <Btn variant="danger" onClick={() => handleDecision('rejected')} disabled={tsDecision.isPending}>✗ Reject</Btn>
              <Btn variant="ghost" onClick={() => setSelected(null)}>Close</Btn>
            </div>
          )}
        </Modal>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// EXPENSES
// ════════════════════════════════════════════════════════════════════════════
function AddExpenseModal({ onClose }: { onClose: () => void }) {
  const create = useCreateExpense();
  const [errMsg, setErrMsg] = useState('');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    category: 'travel', amount: '', currency: 'GBP',
    description: '', expenseDate: new Date().toISOString().split('T')[0],
  });
  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.amount || !form.description) { setErrMsg('Amount and description are required'); return; }
    if (isNaN(Number(form.amount)) || Number(form.amount) <= 0) { setErrMsg('Enter a valid amount'); return; }
    setSaving(true); setErrMsg('');
    try { await create.mutateAsync({ ...form, amount: Number(form.amount) }); onClose(); }
    catch (e: any) { setErrMsg(e.message ?? 'Failed to submit expense'); }
    finally { setSaving(false); }
  };

  return (
    <Modal title="Submit Expense Claim" onClose={onClose}>
      {errMsg && <Alert type="error" message={errMsg} />}
      <FormField label="Category" required>
        <select style={selectStyle} value={form.category} onChange={e => set('category', e.target.value)}>
          <option value="travel">✈️ Travel</option>
          <option value="accommodation">🏨 Accommodation</option>
          <option value="meals">🍽️ Meals</option>
          <option value="equipment">💻 Equipment</option>
          <option value="training">🎓 Training</option>
          <option value="software">📱 Software</option>
          <option value="other">📦 Other</option>
        </select>
      </FormField>
      <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr', gap:12 }}>
        <FormField label="Amount" required>
          <input style={inputStyle} type="number" min="0" step="0.01" placeholder="0.00" value={form.amount} onChange={e => set('amount', e.target.value)} />
        </FormField>
        <FormField label="Currency">
          <select style={selectStyle} value={form.currency} onChange={e => set('currency', e.target.value)}>
            <option value="GBP">GBP £</option>
            <option value="USD">USD $</option>
            <option value="EUR">EUR €</option>
          </select>
        </FormField>
      </div>
      <FormField label="Description" required>
        <input style={inputStyle} placeholder="e.g. Train to client site in Manchester" value={form.description} onChange={e => set('description', e.target.value)} />
      </FormField>
      <FormField label="Date" required>
        <input style={inputStyle} type="date" value={form.expenseDate} onChange={e => set('expenseDate', e.target.value)} />
      </FormField>
      <FormActions onCancel={onClose} onSave={handleSave} saving={saving} saveLabel="Submit Claim" />
    </Modal>
  );
}

export function ExpensesModule() {
  const [tab, setTab] = useState('all');
  const [selected, setSelected] = useState<ExpenseClaim | null>(null);
  const [showAdd, setShowAdd] = useState(false);

  const params = tab === 'mine' ? { mine: 'true' } : tab === 'pending' ? { status: 'pending' } : {};
  const { data: expenses, isLoading, refetch } = useExpenses(params);
  const decision = useExpenseDecision(selected?.id ?? '');

  const items = expenses ?? [];
  const pending = items.filter(e => e.status === 'pending');
  const pendingValue = pending.reduce((a, e) => a + e.amount, 0);
  const approvedValue = items.filter(e => e.status === 'approved').reduce((a, e) => a + e.amount, 0);

  const handleDecision = async (dec: 'approved' | 'rejected') => {
    if (!selected) return;
    try { await decision.mutateAsync({ decision: dec }); setSelected(null); refetch(); }
    catch (e: any) { alert(e.message); }
  };

  const ICONS: Record<string, string> = { travel:'✈️', accommodation:'🏨', meals:'🍽️', equipment:'💻', training:'🎓', software:'📱', other:'📦' };

  const cols: ColDef<ExpenseClaim>[] = [
    { key: 'employee_name', label: 'Employee', render: v => <div style={{display:'flex',alignItems:'center',gap:8}}><Avatar name={v} size={28}/><span style={{fontWeight:600}}>{v}</span></div> },
    { key: 'category', label: 'Category', render: v => `${ICONS[v] ?? '📦'} ${v}` },
    { key: 'description', label: 'Description', muted: true },
    { key: 'expense_date', label: 'Date', render: v => fmtDate(v), muted: true },
    { key: 'amount', label: 'Amount', render: (v, r) => <span style={{fontWeight:700}}>£{Number(v).toFixed(2)}</span> },
    { key: 'status', label: 'Status', render: v => <StatusBadge status={v} /> },
  ];

  return (
    <div className="animate-fadeIn">
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom:20 }}>
        <div><h2 style={{color:'#F1F5F9',fontSize:20,fontWeight:800,margin:0}}>Expenses</h2><p style={{color:'#94A3B8',fontSize:12,margin:'4px 0 0'}}>Claims, approvals and spend</p></div>
        <button onClick={() => setShowAdd(true)} style={{background:'#6366F1',color:'#fff',border:'none',borderRadius:8,padding:'8px 18px',fontSize:13,fontWeight:700,cursor:'pointer'}}>+ Submit Claim</button>
      </div>
      <MetricGrid>
        <MetricCard label="Pending Claims" value={pending.length}                 icon="📋" color={`linear-gradient(135deg,${C.amber},${C.red})`} />
        <MetricCard label="Pending Value"  value={`£${pendingValue.toFixed(0)}`}  icon="💷" color={`linear-gradient(135deg,${C.accent},${C.purple})`} />
        <MetricCard label="Approved MTD"   value={`£${approvedValue.toFixed(0)}`} icon="✅" color={`linear-gradient(135deg,${C.green},${C.teal})`} />
        <MetricCard label="Rejected"       value={items.filter(e=>e.status==='rejected').length} icon="❌" color={`linear-gradient(135deg,${C.red},${C.amber})`} />
      </MetricGrid>
      <Tabs tabs={[{key:'all',label:'All'},{key:'pending',label:`Pending (${pending.length})`},{key:'mine',label:'Mine'}]} active={tab} onChange={setTab} />
      <Card>{isLoading ? <Loading /> : <DataTable cols={cols} rows={items} onRow={setSelected} emptyText="No expense claims" />}</Card>

      {showAdd && <AddExpenseModal onClose={() => { setShowAdd(false); refetch(); }} />}

      {selected && (
        <Modal title="Expense Claim" onClose={() => setSelected(null)}>
          <InfoRow label="Employee"    value={selected.employee_name} />
          <InfoRow label="Category"    value={selected.category} />
          <InfoRow label="Description" value={selected.description} />
          <InfoRow label="Date"        value={fmtDate(selected.expense_date)} />
          <InfoRow label="Amount"      value={`£${Number(selected.amount).toFixed(2)} ${selected.currency}`} />
          <InfoRow label="Status"      value={<StatusBadge status={selected.status} />} />
          {selected.status === 'pending' && (
            <div style={{marginTop:16,display:'flex',gap:8}}>
              <Btn onClick={() => handleDecision('approved')} disabled={decision.isPending}>✓ Approve</Btn>
              <Btn variant="danger" onClick={() => handleDecision('rejected')} disabled={decision.isPending}>✗ Reject</Btn>
              <Btn variant="ghost" onClick={() => setSelected(null)}>Close</Btn>
            </div>
          )}
        </Modal>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// COMPLIANCE
// ════════════════════════════════════════════════════════════════════════════
function AddRTWModal({ onClose }: { onClose: () => void }) {
  const create = useCreateRTW();
  const { data: employees } = useEmployees();
  const [errMsg, setErrMsg] = useState('');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    employeeId: '', checkType: 'manual', docType: '',
    docReference: '', checkDate: new Date().toISOString().split('T')[0], expiryDate: '',
  });
  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.employeeId || !form.docType) { setErrMsg('Employee and document type are required'); return; }
    setSaving(true); setErrMsg('');
    try { await create.mutateAsync(form); onClose(); }
    catch (e: any) { setErrMsg(e.message ?? 'Failed to add check'); }
    finally { setSaving(false); }
  };

  return (
    <Modal title="Add RTW / Compliance Check" onClose={onClose}>
      {errMsg && <Alert type="error" message={errMsg} />}
      <FormField label="Employee" required>
        <select style={selectStyle} value={form.employeeId} onChange={e => set('employeeId', e.target.value)}>
          <option value="">Select employee...</option>
          {(employees?.items ?? []).map(e => <option key={e.id} value={e.id}>{e.first_name} {e.last_name}</option>)}
        </select>
      </FormField>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
        <FormField label="Document Type" required>
          <select style={selectStyle} value={form.docType} onChange={e => set('docType', e.target.value)}>
            <option value="">Select...</option>
            <option value="Passport">Passport</option>
            <option value="BRP Card">BRP Card</option>
            <option value="National ID">National ID</option>
            <option value="Work Visa">Work Visa</option>
            <option value="Right to Work Share Code">Right to Work Share Code</option>
            <option value="DBS Check">DBS Check</option>
            <option value="Driving Licence">Driving Licence</option>
          </select>
        </FormField>
        <FormField label="Check Type">
          <select style={selectStyle} value={form.checkType} onChange={e => set('checkType', e.target.value)}>
            <option value="manual">Manual</option>
            <option value="share_code">Share Code</option>
            <option value="external_service">External Service</option>
          </select>
        </FormField>
      </div>
      <FormField label="Document Reference">
        <input style={inputStyle} placeholder="e.g. Passport number" value={form.docReference} onChange={e => set('docReference', e.target.value)} />
      </FormField>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
        <FormField label="Check Date" required>
          <input style={inputStyle} type="date" value={form.checkDate} onChange={e => set('checkDate', e.target.value)} />
        </FormField>
        <FormField label="Expiry Date">
          <input style={inputStyle} type="date" value={form.expiryDate} onChange={e => set('expiryDate', e.target.value)} />
        </FormField>
      </div>
      <FormActions onCancel={onClose} onSave={handleSave} saving={saving} saveLabel="Add Check" />
    </Modal>
  );
}

export function ComplianceModule() {
  const [tab, setTab] = useState('all');
  const [selected, setSelected] = useState<RTWCheck | null>(null);
  const [showAdd, setShowAdd] = useState(false);

  const params = tab === 'expired' ? { status: 'expired' } : tab === 'expiring' ? { status: 'expiring' } : {};
  const { data: checks, isLoading, refetch } = useCompliance(params);
  const items = checks ?? [];
  const expired  = items.filter(c => c.status === 'expired');
  const expiring = items.filter(c => c.status === 'expiring soon');
  const valid    = items.filter(c => c.status === 'valid');

  const cols: ColDef<RTWCheck>[] = [
    { key: 'employee_name', label: 'Employee', render: v => <div style={{display:'flex',alignItems:'center',gap:8}}><Avatar name={v} size={28}/><span style={{fontWeight:600}}>{v}</span></div> },
    { key: 'doc_type', label: 'Document' },
    { key: 'check_date', label: 'Checked', render: v => fmtDate(v), muted: true },
    { key: 'expiry_date', label: 'Expires', render: v => {
      if (!v) return <span style={{color:C.dim}}>No expiry</span>;
      const isExp = new Date(v) < new Date();
      const isSoon = !isExp && new Date(v) < new Date(Date.now() + 90*86400000);
      return <span style={{color: isExp ? C.red : isSoon ? C.amber : C.text, fontWeight: isExp||isSoon ? 700 : 400}}>{fmtDate(v)}</span>;
    }},
    { key: 'status', label: 'Status', render: v => <StatusBadge status={v} /> },
  ];

  return (
    <div className="animate-fadeIn">
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom:20 }}>
        <div><h2 style={{color:'#F1F5F9',fontSize:20,fontWeight:800,margin:0}}>Compliance & Right to Work</h2><p style={{color:'#94A3B8',fontSize:12,margin:'4px 0 0'}}>RTW checks, visa tracking and compliance status</p></div>
        <button onClick={() => setShowAdd(true)} style={{background:'#6366F1',color:'#fff',border:'none',borderRadius:8,padding:'8px 18px',fontSize:13,fontWeight:700,cursor:'pointer'}}>+ Add Check</button>
      </div>
      {expired.length > 0 && <Alert type="error" message={`${expired.length} compliance item${expired.length > 1 ? 's' : ''} expired — immediate action required`} />}
      {expiring.length > 0 && !expired.length && <Alert type="warning" message={`${expiring.length} item${expiring.length > 1 ? 's' : ''} expiring within 90 days`} />}
      <MetricGrid>
        <MetricCard label="Valid"         value={valid.length}    icon="✅" color={`linear-gradient(135deg,${C.green},${C.teal})`} />
        <MetricCard label="Expiring Soon" value={expiring.length} icon="⚠️" color={`linear-gradient(135deg,${C.amber},${C.red})`} />
        <MetricCard label="Expired"       value={expired.length}  icon="❌" color={`linear-gradient(135deg,${C.red},${C.amber})`} />
        <MetricCard label="Total"         value={items.length}    icon="📋" color={`linear-gradient(135deg,${C.accent},${C.purple})`} />
      </MetricGrid>
      <Tabs tabs={[{key:'all',label:'All'},{key:'expiring',label:`Expiring (${expiring.length})`},{key:'expired',label:`Expired (${expired.length})`}]} active={tab} onChange={setTab} />
      <Card>{isLoading ? <Loading /> : <DataTable cols={cols} rows={items} onRow={setSelected} emptyText="No compliance records" />}</Card>

      {showAdd && <AddRTWModal onClose={() => { setShowAdd(false); refetch(); }} />}

      {selected && (
        <Modal title="Compliance Record" onClose={() => setSelected(null)}>
          <InfoRow label="Employee" value={selected.employee_name} />
          <InfoRow label="Document" value={selected.doc_type} />
          <InfoRow label="Status"   value={<StatusBadge status={selected.status} />} />
          <InfoRow label="Checked"  value={fmtDate(selected.check_date)} />
          <InfoRow label="Expires"  value={selected.expiry_date ? fmtDate(selected.expiry_date) : 'No expiry'} />
          <div style={{marginTop:16,display:'flex',gap:8}}>
            <Btn small>📎 Upload Doc</Btn>
            <Btn small variant="ghost" onClick={() => setSelected(null)}>Close</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

export default LeaveModule;
