import { useState } from 'react';
import {
  useJobs, useCreateJob, useDocuments, useAssets, useCreateAsset, useAssignAsset,
  useTrainingCourses, useTrainingAssignments, useAnnouncements, useCreateAnnouncement,
  useAuditLog, useEmployees,
  type JobPosting, type Document, type Asset, type TrainingCourse, type Announcement, type AuditEvent
} from '../../hooks/api';
import {
  Card, DataTable, SectionHeader, Tabs, Btn, Avatar, StatusBadge,
  Modal, InfoRow, MetricCard, MetricGrid, ProgressBar, Loading,
  Alert, FormField, inputStyle, selectStyle, Badge, C, fmtDate, ColDef
} from '../../components/ui';

// ── shared save row ───────────────────────────────────────────────────────────
function FormActions({ onCancel, onSave, saving, label = 'Save' }: { onCancel:()=>void; onSave:()=>void; saving:boolean; label?:string }) {
  return (
    <div style={{ display:'flex', justifyContent:'flex-end', gap:8, marginTop:24 }}>
      <Btn variant="ghost" onClick={onCancel}>Cancel</Btn>
      <Btn onClick={onSave} disabled={saving}>{saving ? 'Saving...' : label}</Btn>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// RECRUITMENT
// ════════════════════════════════════════════════════════════════════════════
function AddJobModal({ onClose }: { onClose:()=>void }) {
  const create = useCreateJob();
  const [errMsg, setErrMsg] = useState('');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    title:'', location:'', locationType:'hybrid',
    description:'', requirements:'',
    salaryMin:'', salaryMax:'', currency:'GBP', closingDate:'',
  });
  const set = (k:string, v:string) => setForm(f => ({ ...f, [k]:v }));

  const handleSave = async () => {
    if (!form.title.trim()) { setErrMsg('Job title is required'); return; }
    setSaving(true); setErrMsg('');
    try {
      await create.mutateAsync({
        ...form,
        salaryMin: form.salaryMin ? Number(form.salaryMin) : undefined,
        salaryMax: form.salaryMax ? Number(form.salaryMax) : undefined,
        closingDate: form.closingDate || undefined,
      });
      onClose();
    }
    catch (e:any) { setErrMsg(e.message ?? 'Failed to create posting'); }
    finally { setSaving(false); }
  };

  return (
    <Modal title="Post New Job" onClose={onClose} wide>
      {errMsg && <Alert type="error" message={errMsg} />}
      <FormField label="Job Title" required>
        <input style={inputStyle} placeholder="e.g. Senior React Developer" value={form.title} onChange={e => set('title', e.target.value)} />
      </FormField>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
        <FormField label="Location">
          <input style={inputStyle} placeholder="e.g. London HQ" value={form.location} onChange={e => set('location', e.target.value)} />
        </FormField>
        <FormField label="Location Type">
          <select style={selectStyle} value={form.locationType} onChange={e => set('locationType', e.target.value)}>
            <option value="office">Office</option>
            <option value="remote">Remote</option>
            <option value="hybrid">Hybrid</option>
          </select>
        </FormField>
        <FormField label="Salary Min">
          <input style={inputStyle} type="number" placeholder="e.g. 45000" value={form.salaryMin} onChange={e => set('salaryMin', e.target.value)} />
        </FormField>
        <FormField label="Salary Max">
          <input style={inputStyle} type="number" placeholder="e.g. 65000" value={form.salaryMax} onChange={e => set('salaryMax', e.target.value)} />
        </FormField>
        <FormField label="Currency">
          <select style={selectStyle} value={form.currency} onChange={e => set('currency', e.target.value)}>
            <option value="GBP">GBP £</option>
            <option value="USD">USD $</option>
            <option value="EUR">EUR €</option>
          </select>
        </FormField>
        <FormField label="Closing Date">
          <input style={inputStyle} type="date" value={form.closingDate} onChange={e => set('closingDate', e.target.value)} />
        </FormField>
      </div>
      <FormField label="Job Description">
        <textarea style={{ ...inputStyle, height:100, resize:'vertical' }} placeholder="Role overview, responsibilities..." value={form.description} onChange={e => set('description', e.target.value)} />
      </FormField>
      <FormField label="Requirements">
        <textarea style={{ ...inputStyle, height:80, resize:'vertical' }} placeholder="Skills, experience, qualifications..." value={form.requirements} onChange={e => set('requirements', e.target.value)} />
      </FormField>
      <FormActions onCancel={onClose} onSave={handleSave} saving={saving} label="Post Job" />
    </Modal>
  );
}

export function RecruitmentModule() {
  const [selected, setSelected] = useState<JobPosting | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const { data: jobs, isLoading, refetch } = useJobs();
  const items = jobs ?? [];
  const open = items.filter(j => j.status === 'open');
  const interviewing = items.filter(j => j.status === 'interviewing');

  return (
    <div className="animate-fadeIn">
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom:20 }}>
        <div><h2 style={{color:'#F1F5F9',fontSize:20,fontWeight:800,margin:0}}>Recruitment</h2><p style={{color:'#94A3B8',fontSize:12,margin:'4px 0 0'}}>Active roles, pipeline and candidates</p></div>
        <button onClick={() => setShowAdd(true)} style={{background:'#6366F1',color:'#fff',border:'none',borderRadius:8,padding:'8px 18px',fontSize:13,fontWeight:700,cursor:'pointer'}}>+ Post Job</button>
      </div>
      <MetricGrid>
        <MetricCard label="Open Roles"   value={open.length}                                icon="💼" color={`linear-gradient(135deg,${C.accent},${C.purple})`} />
        <MetricCard label="Interviewing" value={interviewing.length}                        icon="🎤" color={`linear-gradient(135deg,${C.sky},${C.accent})`} />
        <MetricCard label="Applications" value={items.reduce((a,j) => a+(j.applicant_count??0),0)} icon="👤" color={`linear-gradient(135deg,${C.teal},${C.green})`} />
        <MetricCard label="Total Roles"  value={items.length}                               icon="📋" color={`linear-gradient(135deg,${C.amber},${C.red})`} />
      </MetricGrid>

      {isLoading ? <Loading /> : (
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          {items.map(job => (
            <Card key={job.id} onClick={() => setSelected(job)} style={{ cursor:'pointer' }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
                <div>
                  <div style={{ fontWeight:800, color:C.text, fontSize:15, marginBottom:8 }}>{job.title}</div>
                  <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                    {job.department_name && <Badge color={C.sky}>{job.department_name}</Badge>}
                    {job.location && <Badge color={C.teal}>{job.location}</Badge>}
                    <Badge color={C.purple}>{job.location_type}</Badge>
                  </div>
                </div>
                <StatusBadge status={job.status} />
              </div>
              <div style={{ display:'flex', gap:24, marginTop:14, paddingTop:14, borderTop:`1px solid ${C.border}33`, fontSize:12 }}>
                <span style={{color:C.muted}}>👤 <span style={{color:C.text,fontWeight:700}}>{job.applicant_count ?? 0}</span> applicants</span>
                {job.closing_date && <span style={{color:C.muted}}>⏰ Closes <span style={{color:C.amber}}>{fmtDate(job.closing_date)}</span></span>}
              </div>
            </Card>
          ))}
          {items.length === 0 && (
            <div style={{ textAlign:'center', padding:'60px 20px', color:C.dim }}>
              <div style={{fontSize:40,marginBottom:12}}>💼</div>
              <div>No job postings yet — create your first role</div>
            </div>
          )}
        </div>
      )}

      {showAdd && <AddJobModal onClose={() => { setShowAdd(false); refetch(); }} />}

      {selected && (
        <Modal title={selected.title} onClose={() => setSelected(null)}>
          {selected.department_name && <InfoRow label="Department" value={selected.department_name} />}
          {selected.location && <InfoRow label="Location" value={`${selected.location} (${selected.location_type})`} />}
          <InfoRow label="Status"       value={<StatusBadge status={selected.status} />} />
          <InfoRow label="Applications" value={selected.applicant_count ?? 0} />
          {selected.closing_date && <InfoRow label="Closes" value={fmtDate(selected.closing_date)} />}
          <div style={{marginTop:16,display:'flex',gap:8}}>
            <Btn small>View Pipeline</Btn>
            <Btn small variant="danger">Close Role</Btn>
            <Btn small variant="ghost" onClick={() => setSelected(null)}>Close</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// DOCUMENTS
// ════════════════════════════════════════════════════════════════════════════
export function DocumentsModule() {
  const [search, setSearch] = useState('');
  const { data: docs, isLoading } = useDocuments();
  const items = (docs ?? []).filter(d =>
    !search || d.name.toLowerCase().includes(search.toLowerCase()) || d.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="animate-fadeIn">
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom:20 }}>
        <div><h2 style={{color:'#F1F5F9',fontSize:20,fontWeight:800,margin:0}}>Document Management</h2><p style={{color:'#94A3B8',fontSize:12,margin:'4px 0 0'}}>{docs?.length ?? 0} documents in R2 storage</p></div>
        <button style={{background:'#6366F1',color:'#fff',border:'none',borderRadius:8,padding:'8px 18px',fontSize:13,fontWeight:700,cursor:'pointer'}}>+ Upload</button>
      </div>
      <MetricGrid>
        {['Policy','Legal','Onboarding','General'].map(cat => (
          <MetricCard key={cat} label={cat} value={(docs ?? []).filter(d => d.category === cat).length} icon="📄" color={`linear-gradient(135deg,${C.accent},${C.purple})`} />
        ))}
      </MetricGrid>
      <div style={{ marginBottom:16 }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search documents..."
          style={{ background:C.elevated, border:`1px solid ${C.border}`, borderRadius:10, padding:'9px 14px', color:C.text, fontSize:13, outline:'none', width:'100%', boxSizing:'border-box' }} />
      </div>
      {isLoading ? <Loading /> : (
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {items.map(doc => (
            <Card key={doc.id} onClick={() => alert(`Requesting download for ${doc.name}...`)} style={{ cursor:'pointer' }}>
              <div style={{ display:'flex', alignItems:'center', gap:14 }}>
                <div style={{fontSize:28,flexShrink:0}}>📄</div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontWeight:700,color:C.text,fontSize:13}}>{doc.name}</div>
                  <div style={{fontSize:11,color:C.muted,marginTop:2}}>
                    {doc.size_bytes ? `${(doc.size_bytes/1024/1024).toFixed(1)} MB · ` : ''}{fmtDate(doc.created_at)}{doc.uploaded_by_email ? ` · ${doc.uploaded_by_email}` : ''}
                  </div>
                </div>
                <div style={{display:'flex',gap:8,alignItems:'center',flexShrink:0}}>
                  <Badge color={C.sky}>{doc.category}</Badge>
                  <Badge color={C.teal}>{doc.access_level}</Badge>
                  <Btn small variant="ghost">⬇ Download</Btn>
                </div>
              </div>
            </Card>
          ))}
          {items.length === 0 && <div style={{textAlign:'center',padding:'60px 20px',color:C.dim}}><div style={{fontSize:40,marginBottom:12}}>📂</div><div>{search ? 'No documents match your search' : 'No documents uploaded yet'}</div></div>}
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// ASSETS
// ════════════════════════════════════════════════════════════════════════════
function AddAssetModal({ onClose }: { onClose:()=>void }) {
  const create = useCreateAsset();
  const { data: employees } = useEmployees();
  const [errMsg, setErrMsg] = useState('');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name:'', category:'laptop', serialNumber:'', purchaseDate:'',
    purchaseValue:'', assignedToId:'', location:'', notes:'',
  });
  const set = (k:string, v:string) => setForm(f => ({ ...f, [k]:v }));

  const handleSave = async () => {
    if (!form.name.trim()) { setErrMsg('Asset name is required'); return; }
    setSaving(true); setErrMsg('');
    try {
      await create.mutateAsync({
        ...form,
        purchaseValue: form.purchaseValue ? Number(form.purchaseValue) : undefined,
        assignedToId: form.assignedToId || undefined,
        serialNumber: form.serialNumber || undefined,
        purchaseDate: form.purchaseDate || undefined,
      });
      onClose();
    }
    catch (e:any) { setErrMsg(e.message ?? 'Failed to register asset'); }
    finally { setSaving(false); }
  };

  return (
    <Modal title="Register Asset" onClose={onClose} wide>
      {errMsg && <Alert type="error" message={errMsg} />}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
        <FormField label="Asset Name" required>
          <input style={inputStyle} placeholder="e.g. MacBook Pro 16 M3" value={form.name} onChange={e => set('name', e.target.value)} />
        </FormField>
        <FormField label="Category">
          <select style={selectStyle} value={form.category} onChange={e => set('category', e.target.value)}>
            <option value="laptop">💻 Laptop</option>
            <option value="monitor">🖥️ Monitor</option>
            <option value="phone">📱 Phone</option>
            <option value="tablet">📟 Tablet</option>
            <option value="peripheral">⌨️ Peripheral</option>
            <option value="furniture">🪑 Furniture</option>
            <option value="vehicle">🚗 Vehicle</option>
            <option value="other">📦 Other</option>
          </select>
        </FormField>
        <FormField label="Serial Number">
          <input style={inputStyle} placeholder="e.g. MBP-2025-001" value={form.serialNumber} onChange={e => set('serialNumber', e.target.value)} />
        </FormField>
        <FormField label="Purchase Value (£)">
          <input style={inputStyle} type="number" min="0" placeholder="0.00" value={form.purchaseValue} onChange={e => set('purchaseValue', e.target.value)} />
        </FormField>
        <FormField label="Purchase Date">
          <input style={inputStyle} type="date" value={form.purchaseDate} onChange={e => set('purchaseDate', e.target.value)} />
        </FormField>
        <FormField label="Assign To">
          <select style={selectStyle} value={form.assignedToId} onChange={e => set('assignedToId', e.target.value)}>
            <option value="">Unassigned</option>
            {(employees?.items ?? []).map(e => <option key={e.id} value={e.id}>{e.first_name} {e.last_name}</option>)}
          </select>
        </FormField>
        <FormField label="Location">
          <input style={inputStyle} placeholder="e.g. London HQ" value={form.location} onChange={e => set('location', e.target.value)} />
        </FormField>
      </div>
      <FormField label="Notes">
        <textarea style={{ ...inputStyle, height:60, resize:'vertical' }} placeholder="Optional notes..." value={form.notes} onChange={e => set('notes', e.target.value)} />
      </FormField>
      <FormActions onCancel={onClose} onSave={handleSave} saving={saving} label="Register Asset" />
    </Modal>
  );
}

export function AssetsModule() {
  const [selected, setSelected] = useState<Asset | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [showAssign, setShowAssign] = useState(false);
  const { data: assets, isLoading, refetch } = useAssets();
  const { data: employees } = useEmployees();
  const assign = useAssignAsset(selected?.id ?? '');
  const [assignTo, setAssignTo] = useState('');
  const items = assets ?? [];

  const handleAssign = async () => {
    if (!assignTo || !selected) return;
    try { await assign.mutateAsync({ employeeId: assignTo }); setShowAssign(false); setSelected(null); refetch(); }
    catch (e:any) { alert(e.message); }
  };

  const cols: ColDef<Asset>[] = [
    { key:'name', label:'Asset', render: v => <span style={{fontWeight:700}}>{v}</span> },
    { key:'category', label:'Category', muted:true },
    { key:'serial_number', label:'Serial', muted:true },
    { key:'assigned_to_name', label:'Assigned To', render: v => v
      ? <div style={{display:'flex',alignItems:'center',gap:6}}><Avatar name={v} size={22}/>{v}</div>
      : <span style={{color:C.dim}}>—</span>
    },
    { key:'purchase_value', label:'Value', render: v => v ? <span style={{color:C.teal}}>£{Number(v).toLocaleString()}</span> : '—' },
    { key:'status', label:'Status', render: v => <StatusBadge status={v} /> },
  ];

  return (
    <div className="animate-fadeIn">
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom:20 }}>
        <div><h2 style={{color:'#F1F5F9',fontSize:20,fontWeight:800,margin:0}}>Asset Management</h2><p style={{color:'#94A3B8',fontSize:12,margin:'4px 0 0'}}>Hardware register, assignments and lifecycle</p></div>
        <button onClick={() => setShowAdd(true)} style={{background:'#6366F1',color:'#fff',border:'none',borderRadius:8,padding:'8px 18px',fontSize:13,fontWeight:700,cursor:'pointer'}}>+ Register Asset</button>
      </div>
      <MetricGrid>
        <MetricCard label="Total"     value={items.length}                                      icon="💻" color={`linear-gradient(135deg,${C.accent},${C.purple})`} />
        <MetricCard label="In Use"    value={items.filter(a=>a.status==='in_use').length}       icon="👤" color={`linear-gradient(135deg,${C.sky},${C.accent})`} />
        <MetricCard label="Available" value={items.filter(a=>a.status==='available').length}    icon="✅" color={`linear-gradient(135deg,${C.green},${C.teal})`} />
        <MetricCard label="Value"     value={`£${items.reduce((a,x)=>a+(x.purchase_value??0),0).toLocaleString()}`} icon="💷" color={`linear-gradient(135deg,${C.amber},${C.red})`} />
      </MetricGrid>
      <Card>{isLoading ? <Loading /> : <DataTable cols={cols} rows={items} onRow={setSelected} emptyText="No assets registered" />}</Card>

      {showAdd && <AddAssetModal onClose={() => { setShowAdd(false); refetch(); }} />}

      {selected && (
        <Modal title={selected.name} onClose={() => setSelected(null)}>
          <InfoRow label="Category"    value={selected.category} />
          <InfoRow label="Serial"      value={selected.serial_number ?? '—'} />
          <InfoRow label="Status"      value={<StatusBadge status={selected.status} />} />
          <InfoRow label="Assigned To" value={selected.assigned_to_name ?? 'Unassigned'} />
          <InfoRow label="Value"       value={selected.purchase_value ? `£${Number(selected.purchase_value).toLocaleString()}` : '—'} />

          {showAssign ? (
            <div style={{ marginTop:16 }}>
              <FormField label="Assign To">
                <select style={selectStyle} value={assignTo} onChange={e => setAssignTo(e.target.value)}>
                  <option value="">Select employee...</option>
                  {(employees?.items ?? []).map(e => <option key={e.id} value={e.id}>{e.first_name} {e.last_name}</option>)}
                </select>
              </FormField>
              <div style={{display:'flex',gap:8,marginTop:8}}>
                <Btn small onClick={handleAssign} disabled={assign.isPending}>Assign</Btn>
                <Btn small variant="ghost" onClick={() => setShowAssign(false)}>Cancel</Btn>
              </div>
            </div>
          ) : (
            <div style={{marginTop:16,display:'flex',gap:8}}>
              <Btn small onClick={() => setShowAssign(true)}>Reassign</Btn>
              <Btn small variant="ghost" onClick={() => setSelected(null)}>Close</Btn>
            </div>
          )}
        </Modal>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// TRAINING
// ════════════════════════════════════════════════════════════════════════════
export function TrainingModule() {
  const [tab, setTab] = useState('courses');
  const { data: courses, isLoading: cLoading } = useTrainingCourses();
  const { data: assignments, isLoading: aLoading } = useTrainingAssignments();
  const allCourses = courses ?? [];
  const allAssignments = assignments ?? [];
  const completed = allAssignments.filter(a => a.status === 'completed');
  const overdue   = allAssignments.filter(a => a.status === 'overdue' || (a.status !== 'completed' && a.due_date && new Date(a.due_date) < new Date()));
  const mandatory = allAssignments.filter(a => a.mandatory === 1 && a.status !== 'completed');

  const cCols: ColDef<TrainingCourse>[] = [
    { key:'name', label:'Course', render: v => <span style={{fontWeight:700}}>{v}</span> },
    { key:'mandatory', label:'Type', render: v => <Badge color={v ? C.red : C.teal}>{v ? 'Mandatory' : 'Optional'}</Badge> },
    { key:'duration_hours', label:'Duration', render: v => v ? `${v}h` : '—', muted:true },
    { key:'assignment_count', label:'Assigned', muted:true },
    { key:'completed_count', label:'Completed', render: (v, r) => (
      <div style={{display:'flex',alignItems:'center',gap:8,minWidth:100}}>
        <ProgressBar value={r.assignment_count > 0 ? Math.round(v/r.assignment_count*100) : 0} color={C.green} height={4} />
        <span style={{fontSize:11,color:C.muted,flexShrink:0}}>{v}/{r.assignment_count}</span>
      </div>
    )},
  ];

  const aCols: ColDef<typeof allAssignments[0]>[] = [
    { key:'employee_name', label:'Employee', render: v => <div style={{display:'flex',alignItems:'center',gap:8}}><Avatar name={v} size={26}/><span style={{fontWeight:600}}>{v}</span></div> },
    { key:'course_name', label:'Course' },
    { key:'mandatory', label:'Type', render: v => <Badge color={v ? C.red : C.teal}>{v ? 'Mandatory' : 'Optional'}</Badge> },
    { key:'status', label:'Status', render: v => <StatusBadge status={v} /> },
    { key:'due_date', label:'Due', render: v => fmtDate(v), muted:true },
    { key:'score', label:'Score', render: v => v ? <span style={{color:C.green,fontWeight:700}}>{v}%</span> : '—', muted:true },
  ];

  return (
    <div className="animate-fadeIn">
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom:20 }}>
        <div><h2 style={{color:'#F1F5F9',fontSize:20,fontWeight:800,margin:0}}>Training Management</h2><p style={{color:'#94A3B8',fontSize:12,margin:'4px 0 0'}}>Mandatory and optional learning</p></div>
        <button style={{background:'#6366F1',color:'#fff',border:'none',borderRadius:8,padding:'8px 18px',fontSize:13,fontWeight:700,cursor:'pointer'}}>+ Add Course</button>
      </div>
      {mandatory.length > 0 && <Alert type="warning" message={`${mandatory.length} mandatory training item${mandatory.length > 1 ? 's' : ''} incomplete`} />}
      <MetricGrid>
        <MetricCard label="Completed"   value={completed.length}  icon="🎓" color={`linear-gradient(135deg,${C.green},${C.teal})`} />
        <MetricCard label="In Progress" value={allAssignments.filter(a=>a.status==='in_progress').length} icon="📚" color={`linear-gradient(135deg,${C.sky},${C.accent})`} />
        <MetricCard label="Overdue"     value={overdue.length}    icon="⚠️" color={`linear-gradient(135deg,${C.red},${C.amber})`} />
        <MetricCard label="Courses"     value={allCourses.length} icon="📖" color={`linear-gradient(135deg,${C.accent},${C.purple})`} />
      </MetricGrid>
      <Tabs tabs={[{key:'courses',label:'Courses'},{key:'assignments',label:'Assignments'}]} active={tab} onChange={setTab} />
      <Card>
        {tab === 'courses'
          ? (cLoading ? <Loading /> : <DataTable cols={cCols} rows={allCourses} emptyText="No courses" />)
          : (aLoading ? <Loading /> : <DataTable cols={aCols} rows={allAssignments} emptyText="No assignments" />)
        }
      </Card>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// ANNOUNCEMENTS
// ════════════════════════════════════════════════════════════════════════════
function AddAnnouncementModal({ onClose }: { onClose:()=>void }) {
  const create = useCreateAnnouncement();
  const [errMsg, setErrMsg] = useState('');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ title:'', body:'', priority:'medium', audience:'all_staff', pinned:false });
  const set = (k:string, v:any) => setForm(f => ({ ...f, [k]:v }));

  const handleSave = async () => {
    if (!form.title.trim() || !form.body.trim()) { setErrMsg('Title and body are required'); return; }
    setSaving(true); setErrMsg('');
    try { await create.mutateAsync(form); onClose(); }
    catch (e:any) { setErrMsg(e.message ?? 'Failed to post announcement'); }
    finally { setSaving(false); }
  };

  return (
    <Modal title="New Announcement" onClose={onClose} wide>
      {errMsg && <Alert type="error" message={errMsg} />}
      <FormField label="Title" required>
        <input style={inputStyle} placeholder="e.g. Q3 All-Hands — 15 July" value={form.title} onChange={e => set('title', e.target.value)} />
      </FormField>
      <FormField label="Body" required>
        <textarea style={{ ...inputStyle, height:120, resize:'vertical' }} placeholder="Announcement body..." value={form.body} onChange={e => set('body', e.target.value)} />
      </FormField>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
        <FormField label="Priority">
          <select style={selectStyle} value={form.priority} onChange={e => set('priority', e.target.value)}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </FormField>
        <FormField label="Audience">
          <select style={selectStyle} value={form.audience} onChange={e => set('audience', e.target.value)}>
            <option value="all_staff">All Staff</option>
            <option value="managers">Managers</option>
            <option value="department">Department</option>
          </select>
        </FormField>
      </div>
      <label style={{ display:'flex', alignItems:'center', gap:8, fontSize:13, color:C.muted, cursor:'pointer', marginTop:8 }}>
        <input type="checkbox" checked={form.pinned} onChange={e => set('pinned', e.target.checked)} />
        📌 Pin this announcement
      </label>
      <FormActions onCancel={onClose} onSave={handleSave} saving={saving} label="Post Announcement" />
    </Modal>
  );
}

export function AnnouncementsModule() {
  const { data: announcements, isLoading, refetch } = useAnnouncements();
  const [showAdd, setShowAdd] = useState(false);
  const items = announcements ?? [];
  const priorityColors: Record<string,string> = { high:C.red, medium:C.amber, low:C.teal };
  const priorityIcons:  Record<string,string> = { high:'🚨', medium:'📢', low:'📌' };

  return (
    <div className="animate-fadeIn">
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom:20 }}>
        <div><h2 style={{color:'#F1F5F9',fontSize:20,fontWeight:800,margin:0}}>Announcements</h2><p style={{color:'#94A3B8',fontSize:12,margin:'4px 0 0'}}>Company-wide and targeted communications</p></div>
        <button onClick={() => setShowAdd(true)} style={{background:'#6366F1',color:'#fff',border:'none',borderRadius:8,padding:'8px 18px',fontSize:13,fontWeight:700,cursor:'pointer'}}>+ New Announcement</button>
      </div>
      {isLoading ? <Loading /> : (
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          {items.map(a => (
            <Card key={a.id} style={{ borderLeft:`4px solid ${priorityColors[a.priority] ?? C.accent}` }}>
              {a.pinned === 1 && <div style={{fontSize:10,color:C.accent,fontWeight:700,textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:8}}>📌 Pinned</div>}
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:10 }}>
                <div>
                  <div style={{fontWeight:800,color:C.text,fontSize:15,marginBottom:6}}>{priorityIcons[a.priority]} {a.title}</div>
                  <div style={{display:'flex',gap:8}}>
                    <Badge color={priorityColors[a.priority] ?? C.accent}>{a.priority}</Badge>
                    <Badge color={C.sky}>{a.audience}</Badge>
                  </div>
                </div>
                <div style={{fontSize:11,color:C.dim,textAlign:'right',flexShrink:0,marginLeft:12}}>
                  <div>{fmtDate(a.created_at)}</div>
                  {a.author_name && <div style={{marginTop:3,color:C.muted}}>{a.author_name}</div>}
                </div>
              </div>
              <p style={{color:C.muted,fontSize:13,lineHeight:1.6,margin:0}}>{a.body}</p>
            </Card>
          ))}
          {items.length === 0 && <div style={{textAlign:'center',padding:'60px 20px',color:C.dim}}><div style={{fontSize:40,marginBottom:12}}>📢</div><div>No announcements yet</div></div>}
        </div>
      )}
      {showAdd && <AddAnnouncementModal onClose={() => { setShowAdd(false); refetch(); }} />}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// AUDIT LOG
// ════════════════════════════════════════════════════════════════════════════
export function AuditModule() {
  const [page, setPage] = useState(1);
  const { data, isLoading } = useAuditLog(page);
  const items = data?.items ?? [];
  const meta  = data?.meta;
  const ACTION_COLORS: Record<string,string> = { create:C.green, update:C.amber, delete:C.red, view:C.dim, approve:C.green, reject:C.red, login:C.sky, logout:C.muted, upload:C.teal, download:C.purple };

  const cols: ColDef<AuditEvent>[] = [
    { key:'user_email', label:'User', render: v => <div style={{display:'flex',alignItems:'center',gap:8}}><Avatar name={v} size={24}/><span style={{fontSize:12}}>{v ?? 'System'}</span></div> },
    { key:'action',     label:'Action', render: v => <span style={{color:ACTION_COLORS[v]??C.muted,fontWeight:700,fontSize:11,textTransform:'uppercase',letterSpacing:'0.05em'}}>{v}</span> },
    { key:'resource',   label:'Resource', render: v => v?.replace(/_/g,' '), muted:true },
    { key:'resource_id',label:'ID', render: v => <span style={{fontFamily:'monospace',fontSize:11,color:C.dim}}>{v?.slice(0,8)}…</span> },
    { key:'created_at', label:'When', render: v => fmtDate(v), muted:true },
  ];

  return (
    <div className="animate-fadeIn">
      <SectionHeader title="Audit Log" sub="Immutable record of all platform events" />
      <Card>
        {isLoading ? <Loading /> : <DataTable cols={cols} rows={items} emptyText="No audit events" />}
        {meta && meta.pages > 1 && (
          <div style={{display:'flex',justifyContent:'center',gap:8,marginTop:16,paddingTop:16,borderTop:`1px solid ${C.border}`}}>
            <Btn small variant="ghost" onClick={() => setPage(p => Math.max(1,p-1))} disabled={page===1}>← Prev</Btn>
            <span style={{color:C.muted,fontSize:12,padding:'5px 10px'}}>Page {page} of {meta.pages}</span>
            <Btn small variant="ghost" onClick={() => setPage(p => Math.min(meta.pages,p+1))} disabled={page===meta.pages}>Next →</Btn>
          </div>
        )}
      </Card>
    </div>
  );
}

export default RecruitmentModule;
