import { useState, ReactNode } from 'react';
import { useAuth, AuthProvider } from './context/AuthContext';
import { TenantProvider, useTenant } from './platform/tenancy/TenantContext';
import { usePermission } from './platform/permissions';
import { useAppStore } from './store/appStore';
import { useNotifications } from './hooks/api';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { C } from './platform/branding/theme';

// Module pages
import DashboardModule     from './modules/dashboard/Dashboard';
import HRModule            from './modules/hr/HR';
import LeaveModule         from './modules/leave/Leave';
import TimesheetsModule    from './modules/timesheets/Timesheets';
import ExpensesModule      from './modules/expenses/Expenses';
import ComplianceModule    from './modules/compliance/Compliance';
import PMOModule           from './modules/pmo/PMO';
import RecruitmentModule   from './modules/recruitment/Recruitment';
import DocumentsModule     from './modules/documents/Documents';
import AssetsModule        from './modules/assets/Assets';
import TrainingModule      from './modules/training/Training';
import AnnouncementsModule from './modules/announcements/Announcements';
import AuditModule         from './modules/audit/Audit';
import SchedulerModule     from './modules/scheduler/Scheduler';
import WorkflowModule      from './modules/workflow/Workflow';
import OrgChartModule      from './modules/orgchart/OrgChart';
import OnboardingModule    from './modules/onboarding/Onboarding';
import VisaModule          from './modules/visa/Visa';
import { LeaveBalancesModule } from './modules/leave/Leave';
import { LeaveCalendarModule } from './modules/leave/Leave';
import ReportingModule      from './modules/reporting/Reporting';
import ChecklistsModule     from './modules/checklists/Checklists';
import OffboardingNewModule  from './modules/offboarding/Offboarding';
import SOSModule             from './modules/sos/SOS';
import ResourcesModule       from './modules/resources/Resources';
import SettingsModule        from './modules/settings/Settings';

// Module manifests
import dashboardManifest     from './modules/dashboard/manifest';
import hrManifest            from './modules/hr/manifest';
import leaveManifest         from './modules/leave/manifest';
import timesheetsManifest    from './modules/timesheets/manifest';
import expensesManifest      from './modules/expenses/manifest';
import complianceManifest    from './modules/compliance/manifest';
import pmoManifest           from './modules/pmo/manifest';
import recruitmentManifest   from './modules/recruitment/manifest';
import documentsManifest     from './modules/documents/manifest';
import assetsManifest        from './modules/assets/manifest';
import trainingManifest      from './modules/training/manifest';
import announcementsManifest from './modules/announcements/manifest';
import auditManifest         from './modules/audit/manifest';
import schedulerManifest     from './modules/scheduler/manifest';
import workflowManifest      from './modules/workflow/manifest';
import orgchartManifest      from './modules/orgchart/manifest';
import onboardingManifest    from './modules/onboarding/manifest';
import visaManifest          from './modules/visa/manifest';
import leaveBalancesManifest  from './modules/leave/balances_manifest';
import leaveCalendarManifest  from './modules/leave/calendar_manifest';
import reportingManifest      from './modules/reporting/manifest';
import checklistsManifest     from './modules/checklists/manifest';
import offboardingManifest  from './modules/offboarding/manifest';
import sosManifest          from './modules/sos/manifest';
import resourcesManifest    from './modules/resources/manifest';
import settingsManifest     from './modules/settings/manifest';

const qc = new QueryClient({
  defaultOptions: { queries: { staleTime: 30_000, retry: 1 } },
});

const MODULE_COMPONENTS: Record<string, React.ComponentType> = {
  dashboard: DashboardModule, hr: HRModule, leave: LeaveModule,
  timesheets: TimesheetsModule, expenses: ExpensesModule,
  compliance: ComplianceModule, pmo: PMOModule,
  recruitment: RecruitmentModule, documents: DocumentsModule,
  assets: AssetsModule, training: TrainingModule,
  announcements: AnnouncementsModule, audit: AuditModule,
  scheduler: SchedulerModule,
  workflow:     WorkflowModule,
  orgchart:     OrgChartModule,
  onboarding:    OnboardingModule,
  visa:          VisaModule,
  leavebalances: LeaveBalancesModule,
  leavecalendar:  LeaveCalendarModule,
  reporting:      ReportingModule,
  checklists:     ChecklistsModule,
  offboarding2:   OffboardingNewModule,
  sos:            SOSModule,
  resources:      ResourcesModule,
  settings:       SettingsModule,
};

const ALL_MANIFESTS = [
  dashboardManifest,
  hrManifest,
  leaveManifest,
  timesheetsManifest,
  expensesManifest,
  complianceManifest,
  pmoManifest,
  recruitmentManifest,
  documentsManifest,
  assetsManifest,
  trainingManifest,
  announcementsManifest,
  auditManifest,
  schedulerManifest,
  workflowManifest,
  orgchartManifest,
  onboardingManifest,
  visaManifest,
  leaveBalancesManifest,
  leaveCalendarManifest,
  reportingManifest,
  checklistsManifest,
  offboardingManifest,
  sosManifest,
  resourcesManifest,
  settingsManifest,
];

const NAV_GROUPS = ['core','people','legal','work','comms','admin'] as const;
const GROUP_LABELS: Record<string, string> = {
  core: '', people: 'People', legal: 'Compliance',
  work: 'Work', comms: 'Comms', admin: 'Admin',
};

// ── Notifications Bell ───────────────────────────────────────────────────────
function NotificationsBell() {
  const { data: notifs } = useNotifications();
  const { setModule } = useAppStore();
  const [open, setOpen] = useState(false);
  const urgent  = (notifs ?? []).filter((n: any) => n.priority === 'urgent' || n.priority === 'high');
  const count   = urgent.length;

  return (
    <div style={{ position: 'relative', padding: '8px 14px', borderBottom: `1px solid ${C.border}` }}>
      <button onClick={() => setOpen(!open)} style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'transparent', border: 'none', cursor: 'pointer', color: C.muted, width: '100%', padding: '4px 0' }}>
        <span style={{ fontSize: 16 }}>🔔</span>
        <span style={{ fontSize: 12, fontWeight: 600 }}>Notifications</span>
        {count > 0 && (
          <span style={{ background: C.danger, color: '#fff', borderRadius: '50%', width: 18, height: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 800, marginLeft: 'auto' }}>
            {count > 9 ? '9+' : count}
          </span>
        )}
      </button>
      {open && (
        <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, background: C.card, border: `1px solid ${C.border}`, borderRadius: '0 0 10px 10px', zIndex: 100, maxHeight: 320, overflowY: 'auto', boxShadow: '0 8px 24px #00000066' }}>
          {(notifs ?? []).length === 0 ? (
            <div style={{ padding: '20px 16px', textAlign: 'center', color: C.dim, fontSize: 12 }}>✅ All clear</div>
          ) : (notifs ?? []).map((n: any) => {
            const COLORS: Record<string,string> = { urgent: C.danger, high: C.warning, medium: C.sky, low: C.dim };
            const color = COLORS[n.priority] ?? C.dim;
            return (
              <div key={n.id} onClick={() => { setModule(n.link as any); setOpen(false); }} style={{ display: 'flex', gap: 10, padding: '10px 14px', borderBottom: `1px solid ${C.border}33`, cursor: 'pointer', alignItems: 'flex-start' }}
                onMouseEnter={(e: React.MouseEvent<HTMLDivElement>) => e.currentTarget.style.background = C.elevated}
                onMouseLeave={(e: React.MouseEvent<any>) => e.currentTarget.style.background = 'transparent'}>
                <span style={{ fontSize: 14, flexShrink: 0 }}>{n.icon}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 11, color: C.text, fontWeight: 600, lineHeight: 1.3 }}>{n.title}</div>
                </div>
                <span style={{ background: color + '22', color, borderRadius: 4, fontSize: 8, padding: '1px 5px', fontWeight: 700, textTransform: 'uppercase', flexShrink: 0 }}>{n.priority}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── Shell ─────────────────────────────────────────────────────────────────────
function Shell() {
  const { user, logout } = useAuth();
  const { tenant, isModuleEnabled } = useTenant();
  const { can, isSuperAdmin } = usePermission();
  const { activeModule, setModule } = useAppStore();

  const companyName = tenant?.branding?.company_name ?? 'XavvySuite';
  const logoLetter  = companyName[0].toUpperCase();
  const initials    = user?.email?.slice(0, 2).toUpperCase() ?? '??';
  const roleName    = user?.roles?.[0]?.replace(/_/g, ' ') ?? 'user';

  // Active module component — fall back to dashboard
  const ActiveModule = MODULE_COMPONENTS[activeModule] ?? DashboardModule;

  // Filter nav: module must be enabled for tenant AND user must have at least
  // one of the module's permissions (or be super admin, or module has no perms)
  const visibleManifests = ALL_MANIFESTS.filter((m: any) => {
    if (!isModuleEnabled(m.key) && !['dashboard','audit','scheduler'].includes(m.key)) return false;
    if (isSuperAdmin) return true;
    if (m.permissions.length === 0) return true;
    return m.permissions.some((p: any) => can(p));
  });

  return (
    <div style={{ display:'flex', height:'100vh', background:C.bg, color:C.text, overflow:'hidden', fontFamily:'Inter, system-ui, sans-serif' }}>

      {/* ── Sidebar ─────────────────────────────────────────────────────── */}
      <aside style={{ width:200, background:C.surface, borderRight:`1px solid ${C.border}`, display:'flex', flexDirection:'column', flexShrink:0, overflowY:'auto' }}>

        {/* Logo / brand */}
        <div style={{ padding:'18px 16px 14px', borderBottom:`1px solid ${C.border}` }}>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            {tenant?.branding?.logo_url ? (
              <img src={tenant.branding.logo_url} alt={companyName} style={{ width:28, height:28, borderRadius:6, objectFit:'contain' }} />
            ) : (
              <div style={{ width:28, height:28, borderRadius:8, background:`linear-gradient(135deg,${C.primary},#8B5CF6)`, display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:14, fontWeight:900 }}>
                {logoLetter}
              </div>
            )}
            <div>
              <div style={{ fontWeight:900, color:C.text, fontSize:13, letterSpacing:'-0.02em' }}>{companyName}</div>
              <div style={{ fontSize:9, color:C.primary, fontWeight:700, textTransform:'uppercase', letterSpacing:'0.1em' }}>Platform</div>
            </div>
          </div>
        </div>

        {/* User pill */}
        <div style={{ padding:'12px 14px', borderBottom:`1px solid ${C.border}` }}>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ width:28, height:28, borderRadius:'50%', background:C.primary+'33', border:`1.5px solid ${C.primary}55`, display:'flex', alignItems:'center', justifyContent:'center', color:C.primary, fontSize:10, fontWeight:800, flexShrink:0 }}>
              {initials}
            </div>
            <div style={{ minWidth:0 }}>
              <div style={{ fontSize:11, fontWeight:700, color:C.text, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                {user?.email?.split('@')[0]}
              </div>
              <div style={{ fontSize:9, color:C.primary, textTransform:'uppercase', letterSpacing:'0.06em' }}>{roleName}</div>
            </div>
          </div>
        </div>

        {/* Nav — manifest-driven, tenant-filtered, permission-filtered */}
        <nav style={{ padding:'10px 8px', flex:1 }}>
          {NAV_GROUPS.map(group => {
            const items = visibleManifests.filter((m: any) => m.group === group);
            if (items.length === 0) return null;
            return (
              <div key={group}>
                {GROUP_LABELS[group] && (
                  <div style={{ padding:'12px 10px 4px', fontSize:9, fontWeight:700, color:C.dim, textTransform:'uppercase', letterSpacing:'0.1em' }}>
                    {GROUP_LABELS[group]}
                  </div>
                )}
                {items.map((m: any) => {
                  const isActive = activeModule === m.key;
                  return (
                    <button key={m.key} onClick={() => setModule(m.key as any)} style={{
                      width:'100%', display:'flex', alignItems:'center', gap:9,
                      padding:'8px 10px', borderRadius:8, marginBottom:2, border:'none',
                      background: isActive ? C.primary+'22' : 'transparent',
                      color:      isActive ? '#818CF8'       : C.muted,
                      cursor:'pointer', fontSize:12,
                      fontWeight: isActive ? 700 : 500,
                      borderLeft: isActive ? `3px solid ${C.primary}` : '3px solid transparent',
                      transition:'all 0.12s', textAlign:'left',
                    }}>
                      <span style={{ fontSize:14, width:18, textAlign:'center' }}>{m.icon}</span>
                      {m.title}
                    </button>
                  );
                })}
              </div>
            );
          })}
        </nav>

        {/* Sign out */}
        <div style={{ padding:'10px 8px', borderTop:`1px solid ${C.border}` }}>
          <button onClick={logout} style={{ width:'100%', padding:'8px 10px', background:C.elevated, border:`1px solid ${C.border}`, borderRadius:8, color:C.muted, cursor:'pointer', fontSize:11, fontWeight:700 }}>
            🚪 Sign Out
          </button>
        </div>
      </aside>

      {/* ── Main ──────────────────────────────────────────────────────────── */}
      <main style={{ flex:1, overflowY:'auto', background:C.bg }}>
        <div style={{ maxWidth:1200, margin:'0 auto', padding:'24px 32px' }}>
          <ActiveModule />
        </div>
      </main>
    </div>
  );
}

// ── Login ─────────────────────────────────────────────────────────────────────
function LoginPage() {
  const { login, shell } = useAuth();
  const [mode, setMode]           = useState<'password'|'magic'|'mfa'>('password');
  const [email, setEmail]         = useState('');
  const [password, setPassword]   = useState('');
  const [mfaToken, setMfaToken]   = useState('');
  const [mfaChallenge, setChallenge] = useState('');
  const [magicSent, setMagicSent] = useState(false);
  const [error, setError]         = useState('');
  const [loading, setLoading]     = useState(false);
  const companyName  = shell?.branding?.company_name ?? 'XavvySuite';
  const primaryColor = shell?.branding?.primary_color ?? C.primary;
  const inp = { width:'100%', background:C.elevated, border:`1px solid ${C.border}`, borderRadius:10, padding:'10px 14px', color:C.text, fontSize:13, outline:'none', boxSizing:'border-box' as const };
  const lbl = { display:'block' as const, fontSize:10, fontWeight:700, color:C.dim, textTransform:'uppercase' as const, letterSpacing:'0.08em', marginBottom:6 };

  // SSO callback: pick up tokens from URL hash
  if (typeof window !== 'undefined' && window.location.hash.includes('access_token')) {
    const p = new URLSearchParams(window.location.hash.slice(1));
    const at = p.get('access_token'), rt = p.get('refresh_token');
    if (at && rt) { localStorage.setItem('xs_token',at); localStorage.setItem('xs_refresh',rt); window.location.hash=''; window.location.reload(); }
  }

  const handlePassword = async (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setLoading(true);
    try {
      const result = await login(email, password) as any;
      if (result?.mfaRequired) { setChallenge(result.mfaChallenge); setMode('mfa'); }
    } catch (err: any) { setError(err.message ?? 'Login failed'); }
    finally { setLoading(false); }
  };

  const handleMagicLink = async (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setLoading(true);
    try { await fetch('/api/auth/magic-link',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email})}); setMagicSent(true); }
    catch { setError('Failed to send magic link'); } finally { setLoading(false); }
  };

  const handleMFA = async (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setLoading(true);
    try {
      const res  = await fetch('/api/auth/mfa/verify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:mfaToken,challenge:mfaChallenge})});
      const data = await res.json() as any;
      if (!data.ok) throw new Error(data.error ?? 'Invalid code');
      localStorage.setItem('xs_token',data.data.accessToken); localStorage.setItem('xs_refresh',data.data.refreshToken); window.location.reload();
    } catch(err:any) { setError(err.message??'Invalid code'); } finally { setLoading(false); }
  };

  return (
    <div style={{minHeight:'100vh',background:C.bg,display:'flex',alignItems:'center',justifyContent:'center',padding:20,fontFamily:'Inter,system-ui,sans-serif'}}>
      <div style={{width:'100%',maxWidth:380}}>
        <div style={{textAlign:'center',marginBottom:32}}>
          <div style={{width:52,height:52,borderRadius:16,background:`linear-gradient(135deg,${primaryColor},#8B5CF6)`,display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontWeight:900,fontSize:22,margin:'0 auto 16px',boxShadow:`0 8px 24px ${primaryColor}44`}}>
            {companyName[0]}
          </div>
          <h1 style={{color:C.text,fontSize:24,fontWeight:900,margin:'0 0 4px'}}>{companyName}</h1>
          <p style={{color:C.muted,fontSize:11,margin:0,textTransform:'uppercase',letterSpacing:'0.1em',fontWeight:700}}>Workforce Platform</p>
        </div>

        <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:20,padding:24}}>
          {error&&<div style={{background:C.danger+'15',border:`1px solid ${C.danger}33`,borderRadius:10,padding:'10px 14px',marginBottom:16,color:C.danger,fontSize:13,textAlign:'center'}}>{error}</div>}

          {mode==='mfa'&&(
            <form onSubmit={handleMFA}>
              <div style={{textAlign:'center',marginBottom:20}}><div style={{fontSize:32,marginBottom:8}}>📱</div><div style={{fontWeight:700,color:C.text}}>Two-Factor Auth</div><div style={{fontSize:12,color:C.muted,marginTop:4}}>Enter the 6-digit code from your app</div></div>
              <div style={{marginBottom:16}}><input type="text" maxLength={6} value={mfaToken} onChange={(e:any)=>setMfaToken(e.target.value.replace(/\D/g,''))} style={{...inp,letterSpacing:'0.3em',textAlign:'center',fontSize:24,fontWeight:800}} placeholder="000000" autoFocus /></div>
              <button type="submit" disabled={loading||mfaToken.length!==6} style={{width:'100%',background:primaryColor,color:'#fff',border:'none',borderRadius:10,padding:11,fontSize:14,fontWeight:700,cursor:'pointer'}}>{loading?'Verifying...':'Verify →'}</button>
              <div style={{textAlign:'center',marginTop:12}}><button type="button" onClick={()=>setMode('password')} style={{background:'none',border:'none',color:C.dim,fontSize:12,cursor:'pointer'}}>← Back</button></div>
            </form>
          )}

          {mode==='magic'&&magicSent&&(
            <div style={{textAlign:'center',padding:'10px 0'}}>
              <div style={{fontSize:40,marginBottom:12}}>📧</div>
              <div style={{fontWeight:700,color:C.text,fontSize:15,marginBottom:8}}>Check your email</div>
              <div style={{fontSize:13,color:C.muted}}>Sign-in link sent to <strong>{email}</strong>. Expires in 15 minutes.</div>
              <button onClick={()=>{setMagicSent(false);setMode('password');}} style={{background:'transparent',border:`1px solid ${C.border}`,borderRadius:8,padding:'8px 16px',fontSize:12,color:C.muted,cursor:'pointer',marginTop:16}}>← Back</button>
            </div>
          )}

          {mode!=='mfa'&&!magicSent&&(
            <>
              <div style={{display:'flex',gap:6,marginBottom:20}}>
                {[{k:'password',l:'Password'},{k:'magic',l:'Magic Link'}].map(m=>(
                  <button key={m.k} type="button" onClick={()=>setMode(m.k as any)} style={{flex:1,background:mode===m.k?primaryColor:C.elevated,color:mode===m.k?'#fff':C.muted,border:`1px solid ${mode===m.k?primaryColor:C.border}`,borderRadius:8,padding:'7px 0',fontSize:12,fontWeight:700,cursor:'pointer'}}>{m.l}</button>
                ))}
              </div>

              {mode==='password'&&(
                <form onSubmit={handlePassword}>
                  <div style={{marginBottom:14}}><label style={lbl}>Email</label><input type="email" required value={email} onChange={(e:any)=>setEmail(e.target.value)} style={inp} placeholder="you@company.com" /></div>
                  <div style={{marginBottom:20}}><label style={lbl}>Password</label><input type="password" required value={password} onChange={(e:any)=>setPassword(e.target.value)} style={inp} placeholder="••••••••" /></div>
                  <button type="submit" disabled={loading} style={{width:'100%',background:loading?primaryColor+'AA':primaryColor,color:'#fff',border:'none',borderRadius:10,padding:11,fontSize:14,fontWeight:700,cursor:loading?'wait':'pointer'}}>{loading?'Signing in...':'Sign In →'}</button>
                </form>
              )}

              {mode==='magic'&&(
                <form onSubmit={handleMagicLink}>
                  <div style={{marginBottom:20}}><label style={lbl}>Your email</label><input type="email" required value={email} onChange={(e:any)=>setEmail(e.target.value)} style={inp} placeholder="you@company.com" /></div>
                  <button type="submit" disabled={loading||!email} style={{width:'100%',background:primaryColor,color:'#fff',border:'none',borderRadius:10,padding:11,fontSize:14,fontWeight:700,cursor:'pointer'}}>{loading?'Sending...':'Send Magic Link →'}</button>
                  <div style={{fontSize:11,color:C.dim,textAlign:'center',marginTop:8}}>No password needed. We email you a secure link.</div>
                </form>
              )}

              <div style={{marginTop:20,paddingTop:16,borderTop:`1px solid ${C.border}`}}>
                <div style={{fontSize:10,fontWeight:700,color:C.dim,textTransform:'uppercase',letterSpacing:'0.08em',textAlign:'center',marginBottom:10}}>Or continue with</div>
                <div style={{display:'flex',gap:8}}>
                  {[{href:'/api/auth/entra/redirect',label:'🏢 Microsoft'},{href:'/api/auth/google/redirect',label:'🔵 Google'},{href:'/api/auth/saml/redirect',label:'🔐 SAML'}].map(s=>(
                    <a key={s.href} href={s.href} style={{flex:1,display:'flex',alignItems:'center',justifyContent:'center',gap:6,background:C.elevated,border:`1px solid ${C.border}`,borderRadius:10,padding:'9px 0',fontSize:11,fontWeight:600,color:C.muted,textDecoration:'none'}}>{s.label}</a>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Root ──────────────────────────────────────────────────────────────────────
function AppInner() {
  const { user, loading } = useAuth();
  if (loading) return (
    <div style={{ minHeight:'100vh', background:C.bg, display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div style={{ color:C.muted, fontSize:13 }}>Loading...</div>
    </div>
  );
  return user ? <Shell /> : <LoginPage />;
}

export default function App() {
  return (
    <QueryClientProvider client={qc}>
      <AuthProvider>
        <TenantProvider>
          <AppInner />
        </TenantProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}
