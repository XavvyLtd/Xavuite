export default {
  key:'checklists', title:'Checklists', icon:'✅', group:'work',
  permissions:[], navigation:[{ label:'Checklists', path:'/checklists', permission:null }],
};
