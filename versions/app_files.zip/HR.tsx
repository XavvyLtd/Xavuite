import { useState } from 'react';
import {
  useEmployees, useEmployee, useEmployeeHistory,
  useDepartments, useCreateEmployee, useUpdateEmployee
} from '../../hooks/api';
import {
  Card, DataTable, SearchBar, Avatar, StatusBadge,
  Modal, InfoRow, MetricCard, Loading, C, fmtDate,
  FormField, inputStyle, selectStyle, Alert
} from '../../components/ui';
import { PermissionGate, usePermission, PERMISSIONS } from '../../platform/permissions/index';
import { useEmergencyContacts, useCreateEmergencyContact, useCompensation, useCreateCompensation, type EmergencyContact, type CompensationRecord } from '../../hooks/api';
import { useQueryClient } from '@tanstack/react-query';
import { useAppStore } from '../../store/appStore';

// ── Local button primitives (plain elements — no event-loss risk) ─────────────
const PBtn = ({ onClick, disabled, children }: { onClick?: () => void; disabled?: boolean; children: React.ReactNode }) => (
  <button onClick={onClick} disabled={disabled} style={{ background: disabled ? C.primary+'99' : C.primary, color:'#fff', border:'none', borderRadius:8, padding:'8px 18px', fontSize:13, fontWeight:700, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.6 : 1 }}>{children}</button>
);
const GBtn = ({ onClick, children, small }: { onClick?: () => void; children: React.ReactNode; small?: boolean }) => (
  <button onClick={onClick} style={{ background:'transparent', color:C.muted, border:`1px solid ${C.border}`, borderRadius:8, padding: small ? '4px 10px' : '8px 16px', fontSize: small ? 11 : 13, fontWeight:600, cursor:'pointer' }}>{children}</button>
);
const DBtn = ({ onClick, children }: { onClick?: () => void; children: React.ReactNode }) => (
  <button onClick={onClick} style={{ background:C.danger+'22', color:C.danger, border:`1px solid ${C.danger}33`, borderRadius:8, padding:'5px 12px', fontSize:12, fontWeight:600, cursor:'pointer' }}>{children}</button>
);
const AccentBtn = ({ onClick, children }: { onClick?: () => void; children: React.ReactNode }) => (
  <button onClick={onClick} style={{ background:C.primary+'22', color:C.primary, border:`1px solid ${C.primary}33`, borderRadius:8, padding:'5px 12px', fontSize:12, fontWeight:700, cursor:'pointer' }}>{children}</button>
);

// ── Add Employee ──────────────────────────────────────────────────────────────
function AddEmployeeModal({ onClose, departments }: { onClose: () => void; departments: any[] }) {
  const createEmployee = useCreateEmployee();
  const qc = useQueryClient();
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    firstName:'', lastName:'', email:'', departmentId:'',
    startDate: new Date().toISOString().split('T')[0],
    employmentType:'full_time', locationType:'office',
    employmentBasis:'permanent', contractType:'employed',
  });
  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.firstName.trim()) { setError('First name is required'); return; }
    if (!form.lastName.trim())  { setError('Last name is required'); return; }
    if (!form.email.trim())     { setError('Email is required'); return; }
    setSaving(true); setError('');
    try {
      await createEmployee.mutateAsync(form);
      qc.invalidateQueries({ queryKey: ['employees'] });
      onClose();
    } catch (e: any) { setError(e.message ?? 'Failed to create employee'); }
    finally { setSaving(false); }
  };

  return (
    <Modal title="Add New Employee" onClose={onClose} wide>
      {error && <Alert type="error" message={error} />}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
        <FormField label="First Name" required>
          <input style={inputStyle} value={form.firstName} onChange={e => set('firstName', e.target.value)} placeholder="Sarah" />
        </FormField>
        <FormField label="Last Name" required>
          <input style={inputStyle} value={form.lastName} onChange={e => set('lastName', e.target.value)} placeholder="Mitchell" />
        </FormField>
        <FormField label="Work Email" required>
          <input style={inputStyle} type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="s.mitchell@xavvy.uk" />
        </FormField>
        <FormField label="Start Date" required>
          <input style={inputStyle} type="date" value={form.startDate} onChange={e => set('startDate', e.target.value)} />
        </FormField>
        <FormField label="Department">
          <select style={selectStyle} value={form.departmentId} onChange={e => set('departmentId', e.target.value)}>
            <option value="">Select department...</option>
            {departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </FormField>
        <FormField label="Employment Type" required>
          <select style={selectStyle} value={form.employmentType} onChange={e => set('employmentType', e.target.value)}>
            <option value="full_time">Full Time</option>
            <option value="part_time">Part Time</option>
            <option value="contractor">Contractor</option>
            <option value="intern">Intern</option>
            <option value="casual">Casual</option>
          </select>
        </FormField>
        <FormField label="Contract Basis">
          <select style={selectStyle} value={form.employmentBasis} onChange={e => set('employmentBasis', e.target.value)}>
            <option value="permanent">Permanent</option>
            <option value="fixed_term">Fixed Term</option>
            <option value="zero_hours">Zero Hours</option>
          </select>
        </FormField>
        <FormField label="Work Location">
          <select style={selectStyle} value={form.locationType} onChange={e => set('locationType', e.target.value)}>
            <option value="office">Office</option>
            <option value="remote">Remote</option>
            <option value="hybrid">Hybrid</option>
          </select>
        </FormField>
      </div>
      <div style={{ display:'flex', gap:10, marginTop:24, justifyContent:'flex-end' }}>
        <GBtn onClick={onClose}>Cancel</GBtn>
        <PBtn onClick={handleSave} disabled={saving}>{saving ? 'Creating...' : '+ Add Employee'}</PBtn>
      </div>
    </Modal>
  );
}

// ── Edit Employee ─────────────────────────────────────────────────────────────
function EditEmployeeModal({ emp, onClose, departments }: { emp: any; onClose: () => void; departments: any[] }) {
  const update = useUpdateEmployee(emp.id);
  const qc = useQueryClient();
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    firstName:       emp.first_name       ?? '',
    lastName:        emp.last_name        ?? '',
    departmentId:    emp.department_id    ?? '',
    employmentType:  emp.employment_type  ?? 'full_time',
    locationType:    emp.work_location_type ?? 'office',
    employmentBasis: emp.employment_basis ?? 'permanent',
    changeReason:    'correction',
  });
  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    setSaving(true); setError('');
    try {
      await update.mutateAsync(form);
      qc.invalidateQueries({ queryKey: ['employees'] });
      qc.invalidateQueries({ queryKey: ['employees', emp.id] });
      onClose();
    } catch (e: any) { setError(e.message ?? 'Failed to update employee'); }
    finally { setSaving(false); }
  };

  return (
    <Modal title={`Edit — ${emp.first_name} ${emp.last_name}`} onClose={onClose} wide>
      {error && <Alert type="error" message={error} />}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
        <FormField label="First Name">
          <input style={inputStyle} value={form.firstName} onChange={e => set('firstName', e.target.value)} />
        </FormField>
        <FormField label="Last Name">
          <input style={inputStyle} value={form.lastName} onChange={e => set('lastName', e.target.value)} />
        </FormField>
        <FormField label="Department">
          <select style={selectStyle} value={form.departmentId} onChange={e => set('departmentId', e.target.value)}>
            <option value="">Select department...</option>
            {departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </FormField>
        <FormField label="Employment Type">
          <select style={selectStyle} value={form.employmentType} onChange={e => set('employmentType', e.target.value)}>
            <option value="full_time">Full Time</option>
            <option value="part_time">Part Time</option>
            <option value="contractor">Contractor</option>
            <option value="intern">Intern</option>
            <option value="casual">Casual</option>
          </select>
        </FormField>
        <FormField label="Work Location">
          <select style={selectStyle} value={form.locationType} onChange={e => set('locationType', e.target.value)}>
            <option value="office">Office</option>
            <option value="remote">Remote</option>
            <option value="hybrid">Hybrid</option>
          </select>
        </FormField>
        <FormField label="Reason for Change" required>
          <select style={selectStyle} value={form.changeReason} onChange={e => set('changeReason', e.target.value)}>
            <option value="correction">Correction</option>
            <option value="promotion">Promotion</option>
            <option value="transfer">Transfer</option>
            <option value="annual_review">Annual Review</option>
            <option value="other">Other</option>
          </select>
        </FormField>
      </div>
      <div style={{ display:'flex', gap:10, marginTop:24, justifyContent:'flex-end' }}>
        <GBtn onClick={onClose}>Cancel</GBtn>
        <PBtn onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Save Changes'}</PBtn>
      </div>
    </Modal>
  );
}

// ── Employee Detail Modal ─────────────────────────────────────────────────────
function EmployeeModal({ id, onClose, departments }: { id: string; onClose: () => void; departments: any[] }) {
  const { data: emp, isLoading, refetch } = useEmployee(id);
  const { data: history } = useEmployeeHistory(id);
  const { data: emergency } = useEmergencyContacts(id);
  const { data: compensation } = useCompensation(id);
  const { setModule } = useAppStore();
  const [tab, setTab]     = useState<'profile'|'history'|'emergency'|'compensation'>('profile');
  const [showEdit, setShowEdit] = useState(false);

  if (isLoading) return <Modal title="Employee" onClose={onClose}><Loading /></Modal>;
  if (!emp) return null;
  const fullName = `${emp.first_name} ${emp.last_name}`;

  return (
    <>
      <Modal title={fullName} onClose={onClose}>
        <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:20 }}>
          <Avatar name={fullName} size={52} />
          <div>
            <div style={{ fontWeight:800, color:C.text, fontSize:18 }}>{fullName}</div>
            <div style={{ color:C.muted, fontSize:13 }}>{emp.designation_title ?? '—'} · {emp.department_name ?? '—'}</div>
          </div>
        </div>

        <div style={{ display:'flex', gap:6, marginBottom:16, flexWrap:'wrap' }}>
          {(['profile','history','emergency','compensation'] as const).map(t => (
            <button key={t} onClick={() => setTab(t as any)} style={{ background: tab===t ? C.primary : C.elevated, color: tab===t ? '#fff' : C.muted, border:`1px solid ${tab===t ? C.primary : C.border}`, borderRadius:8, padding:'5px 12px', fontSize:11, fontWeight:700, cursor:'pointer', textTransform:'capitalize' }}>
              {t === 'emergency' ? '🆘 Emergency' : t === 'compensation' ? '💷 Pay' : t.charAt(0).toUpperCase()+t.slice(1)}
            </button>
          ))}
        </div>

        {tab === 'profile' && (
          <>
            <InfoRow label="Email"           value={emp.email} />
            <InfoRow label="Employee #"      value={emp.employee_number} />
            <InfoRow label="Status"          value={<StatusBadge status={emp.status} />} />
            <InfoRow label="Employment Type" value={emp.employment_type?.replace(/_/g,' ')} />
            <InfoRow label="Location"        value={emp.work_location_type?.replace(/_/g,' ')} />
            <InfoRow label="Start Date"      value={fmtDate(emp.start_date)} />
            <div style={{ marginTop:16, display:'flex', gap:8, flexWrap:'wrap' }}>
              {/* Edit — only shown if user has HR edit permission */}
              <PermissionGate permission={PERMISSIONS.HR_EDIT}>
                <AccentBtn onClick={() => setShowEdit(true)}>✏️ Edit</AccentBtn>
              </PermissionGate>
              <GBtn onClick={() => { onClose(); setModule('leave'); }}>🌴 Leave</GBtn>
              <GBtn onClick={() => { onClose(); setModule('timesheets'); }}>⏱ Timesheets</GBtn>
              {/* Offboard — only HR managers */}
              <PermissionGate permission={PERMISSIONS.HR_MANAGE}>
                <DBtn onClick={() => {
                  if (window.confirm(`Offboard ${fullName}?`)) alert('Offboarding workflow — coming soon');
                }}>Offboard</DBtn>
              </PermissionGate>
            </div>
          </>
        )}

        {tab === 'history' && (
          <div>
            {(!history || history.length === 0) && <div style={{ color:C.dim, fontSize:13, padding:'20px 0', textAlign:'center' }}>No history recorded yet</div>}
            {history?.map(h => (
              <div key={h.id} style={{ padding:'12px 0', borderBottom:`1px solid ${C.border}33` }}>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                  <span style={{ fontSize:12, fontWeight:700, color:C.primary, textTransform:'capitalize' }}>{h.change_reason?.replace(/_/g,' ') ?? 'Update'}</span>
                  <span style={{ fontSize:11, color:C.dim }}>{fmtDate(h.effective_from)}</span>
                </div>
                <div style={{ fontSize:11, color:C.muted }}>{h.first_name} {h.last_name}</div>
                {h.changed_by_email && <div style={{ fontSize:10, color:C.dim, marginTop:2 }}>by {h.changed_by_email}</div>}
              </div>
            ))}
          </div>
        )}

        {tab === 'emergency' && (
          <div>
            {(!emergency || emergency.length === 0) && (
              <div style={{ color:C.dim, fontSize:13, padding:'20px 0', textAlign:'center' }}>No emergency contacts added yet</div>
            )}
            {(emergency ?? []).map((ec: EmergencyContact) => (
              <div key={ec.id} style={{ padding:'12px 0', borderBottom:`1px solid ${C.border}33` }}>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                  <span style={{ fontWeight:700, color:C.text, fontSize:13 }}>{ec.name}</span>
                  {ec.is_primary===1 && <span style={{ background:C.primary+'22', color:C.primary, borderRadius:4, fontSize:9, padding:'1px 6px', fontWeight:700 }}>PRIMARY</span>}
                </div>
                <div style={{ fontSize:12, color:C.muted }}>{ec.relationship} · {ec.phone}</div>
                {ec.email && <div style={{ fontSize:11, color:C.dim }}>{ec.email}</div>}
              </div>
            ))}
            <button onClick={() => {}} style={{ marginTop:14, background:C.primary+'22', color:C.primary, border:`1px solid ${C.primary}33`, borderRadius:8, padding:'6px 14px', fontSize:12, fontWeight:700, cursor:'pointer' }}>
              + Add Contact
            </button>
          </div>
        )}

        {tab === 'compensation' && (
          <div>
            {(!compensation || compensation.length === 0) && (
              <div style={{ color:C.dim, fontSize:13, padding:'20px 0', textAlign:'center' }}>No compensation records yet</div>
            )}
            {(compensation ?? []).map((c: CompensationRecord, i: number) => (
              <div key={c.id} style={{ padding:'12px 0', borderBottom:`1px solid ${C.border}33` }}>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                  <span style={{ fontWeight:800, color:C.text, fontSize:15 }}>
                    {c.currency} {Number(c.salary).toLocaleString()}
                    <span style={{ fontSize:11, color:C.dim, fontWeight:400, marginLeft:4 }}>/ {c.pay_frequency}</span>
                  </span>
                  {i === 0 && <span style={{ background:C.success+'22', color:C.success, borderRadius:4, fontSize:9, padding:'1px 6px', fontWeight:700 }}>CURRENT</span>}
                </div>
                <div style={{ fontSize:12, color:C.muted }}>
                  From {fmtDate(c.effective_from)}
                  {c.change_reason && ` · ${c.change_reason.replace(/_/g,' ')}`}
                  {c.change_pct !== null && c.change_pct !== undefined && (
                    <span style={{ color: c.change_pct > 0 ? C.success : C.danger, fontWeight:700, marginLeft:6 }}>
                      {c.change_pct > 0 ? '▲' : '▼'} {Math.abs(c.change_pct)}%
                    </span>
                  )}
                </div>
              </div>
            ))}
            <button onClick={() => {}} style={{ marginTop:14, background:C.primary+'22', color:C.primary, border:`1px solid ${C.primary}33`, borderRadius:8, padding:'6px 14px', fontSize:12, fontWeight:700, cursor:'pointer' }}>
              + Add Pay Record
            </button>
          </div>
        )}
      </Modal>

      {showEdit && <EditEmployeeModal emp={emp} departments={departments} onClose={() => { setShowEdit(false); refetch(); }} />}
    </>
  );
}

// ── Main HR Module ────────────────────────────────────────────────────────────
export default function HRModule() {
  const [search, setSearch]         = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showAdd, setShowAdd]       = useState(false);
  const { can } = usePermission();

  const params: Record<string,string> = {};
  if (search)     params.search       = search;
  if (deptFilter) params.departmentId = deptFilter;

  const { data: employees, isLoading, refetch } = useEmployees(params);
  const { data: departments = [] }              = useDepartments();
  const items   = employees?.items ?? [];
  const active  = items.filter(e => e.status === 'active').length;
  const onLeave = items.filter(e => e.status === 'on_leave').length;

  return (
    <div className="animate-fadeIn">
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom:20 }}>
        <div>
          <h2 style={{ color:C.text, fontSize:20, fontWeight:800, margin:0 }}>HR Management</h2>
          <p style={{ color:C.muted, fontSize:12, margin:'4px 0 0' }}>{items.length} employees</p>
        </div>
        {/* Add Employee — only shown with create permission */}
        <PermissionGate permission={PERMISSIONS.HR_CREATE}>
          <button onClick={() => setShowAdd(true)} style={{ background:C.primary, color:'#fff', border:'none', borderRadius:8, padding:'8px 18px', fontSize:13, fontWeight:700, cursor:'pointer' }}>
            + Add Employee
          </button>
        </PermissionGate>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(160px,1fr))', gap:12, marginBottom:24 }}>
        <MetricCard label="Active"      value={active}             icon="✅" color={`linear-gradient(135deg,${C.success},${C.secondary})`} />
        <MetricCard label="On Leave"    value={onLeave}            icon="🌴" color={`linear-gradient(135deg,${C.sky},${C.primary})`} />
        <MetricCard label="Departments" value={departments.length} icon="🏢" color={`linear-gradient(135deg,${C.primary},#8B5CF6)`} />
        <MetricCard label="Total"       value={items.length}       icon="👥" color={`linear-gradient(135deg,#8B5CF6,${C.primary})`} />
      </div>

      <Card>
        <div style={{ display:'flex', gap:10, marginBottom:16 }}>
          <div style={{ flex:1 }}>
            <SearchBar value={search} onChange={setSearch} placeholder="Search name, email, role..." />
          </div>
          <select value={deptFilter} onChange={e => setDeptFilter(e.target.value)} style={{ background:C.elevated, border:`1px solid ${C.border}`, borderRadius:10, padding:'8px 12px', color:C.text, fontSize:13, outline:'none', cursor:'pointer' }}>
            <option value="">All departments</option>
            {departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </div>
        {isLoading ? <Loading /> : (
          <DataTable
            cols={[
              { key:'first_name', label:'Employee', render:(_: any, r: any) => (
                <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                  <Avatar name={`${r.first_name} ${r.last_name}`} />
                  <div>
                    <div style={{ fontWeight:700, fontSize:13 }}>{r.first_name} {r.last_name}</div>
                    <div style={{ fontSize:11, color:C.muted }}>{r.email}</div>
                  </div>
                </div>
              )},
              { key:'department_name',    label:'Department', muted:true },
              { key:'designation_title',  label:'Role',       muted:true },
              { key:'employment_type',    label:'Type',       render:v => v?.replace(/_/g,' '), muted:true },
              { key:'work_location_type', label:'Location',   render:v => v?.replace(/_/g,' '), muted:true },
              { key:'status',             label:'Status',     render:v => <StatusBadge status={v} /> },
            ]}
            rows={items}
            onRow={(r: any) => setSelectedId(r.id)}
            emptyText="No employees yet — add your first one"
          />
        )}
      </Card>

      {showAdd && <AddEmployeeModal onClose={() => { setShowAdd(false); refetch(); }} departments={departments} />}
      {selectedId && <EmployeeModal id={selectedId} departments={departments} onClose={() => setSelectedId(null)} />}
    </div>
  );
}
