export default { key:'resources', title:'Resources', icon:'📊', group:'work', permissions:[], navigation:[{ label:'Resource Planning', path:'/resources', permission:null }] };
