import { useState } from 'react';
import { useSettings, useUpdateBranding, useModuleSettings } from '../../hooks/api';
import { useQueryClient } from '@tanstack/react-query';
import { Card, Loading, Alert, FormField, inputStyle, C } from '../../components/ui';

export default function SettingsModule() {
  const [tab, setTab] = useState<'branding'|'modules'>('branding');
  const { data, isLoading, refetch } = useSettings();
  const updateBranding = useUpdateBranding();
  const { data:modules } = useModuleSettings();
  const qc = useQueryClient();
  const [saved, setSaved] = useState(false);
  const [errMsg, setErrMsg] = useState('');

  const branding = data?.branding;
  const [form, setForm] = useState({ company_name:'', primary_color:'', secondary_color:'' });
  const set = (k:string,v:string) => setForm(f=>({...f,[k]:v}));

  // Init form from loaded data
  useState(()=>{ if(branding){ setForm({ company_name:branding.company_name??'', primary_color:branding.primary_color??'#6366F1', secondary_color:branding.secondary_color??'#14B8A6' }); } });

  const handleSave = async () => {
    setErrMsg(''); setSaved(false);
    try {
      await updateBranding.mutateAsync(form);
      qc.invalidateQueries({queryKey:['settings']});
      setSaved(true); setTimeout(()=>setSaved(false), 3000);
    } catch(e:any) { setErrMsg(e.message??'Failed'); }
  };

  const toggleModule = async (moduleKey:string, enabled:number) => {
    const token = localStorage.getItem('access_token');
    await fetch(`/api/settings/modules/${moduleKey}`, { method:'PATCH', headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`}, body:JSON.stringify({enabled:!enabled}) });
    qc.invalidateQueries({queryKey:['settings','modules']});
  };

  if (isLoading) return <Loading />;

  return (
    <div className="animate-fadeIn">
      <div style={{marginBottom:20}}>
        <h2 style={{color:C.text,fontSize:20,fontWeight:800,margin:0}}>Settings</h2>
        <p style={{color:C.muted,fontSize:12,margin:'4px 0 0'}}>White label, branding and module configuration</p>
      </div>
      <div style={{display:'flex',gap:6,marginBottom:20}}>
        {[{k:'branding',l:'🎨 Branding'},{k:'modules',l:'🧩 Modules'}].map(t=>(
          <button key={t.k} onClick={()=>setTab(t.k as any)} style={{background:tab===t.k?C.primary:C.elevated,color:tab===t.k?'#fff':C.muted,border:`1px solid ${tab===t.k?C.primary:C.border}`,borderRadius:8,padding:'7px 16px',fontSize:12,fontWeight:700,cursor:'pointer'}}>{t.l}</button>
        ))}
      </div>

      {tab==='branding' && (
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:20}}>
          <Card>
            <div style={{fontSize:13,fontWeight:700,color:C.text,marginBottom:16}}>Company Branding</div>
            {errMsg && <Alert type="error" message={errMsg} />}
            {saved  && <Alert type="success" message="Branding saved successfully" />}
            <FormField label="Company Name">
              <input style={inputStyle} value={form.company_name} onChange={e=>set('company_name',e.target.value)} placeholder="Your Company Ltd" />
            </FormField>
            <FormField label="Primary Colour">
              <div style={{display:'flex',gap:8,alignItems:'center'}}>
                <input type="color" value={form.primary_color} onChange={e=>set('primary_color',e.target.value)} style={{width:40,height:36,border:`1px solid ${C.border}`,borderRadius:8,cursor:'pointer',padding:2,background:C.elevated}} />
                <input style={{...inputStyle,flex:1}} value={form.primary_color} onChange={e=>set('primary_color',e.target.value)} placeholder="#6366F1" />
              </div>
            </FormField>
            <FormField label="Secondary Colour">
              <div style={{display:'flex',gap:8,alignItems:'center'}}>
                <input type="color" value={form.secondary_color} onChange={e=>set('secondary_color',e.target.value)} style={{width:40,height:36,border:`1px solid ${C.border}`,borderRadius:8,cursor:'pointer',padding:2,background:C.elevated}} />
                <input style={{...inputStyle,flex:1}} value={form.secondary_color} onChange={e=>set('secondary_color',e.target.value)} placeholder="#14B8A6" />
              </div>
            </FormField>
            <button onClick={handleSave} disabled={updateBranding.isPending} style={{background:C.primary,color:'#fff',border:'none',borderRadius:8,padding:'9px 20px',fontSize:13,fontWeight:700,cursor:'pointer',width:'100%',marginTop:8}}>
              {updateBranding.isPending ? 'Saving...' : 'Save Branding'}
            </button>
          </Card>

          <Card>
            <div style={{fontSize:13,fontWeight:700,color:C.text,marginBottom:16}}>Preview</div>
            <div style={{border:`1px solid ${C.border}`,borderRadius:12,overflow:'hidden'}}>
              <div style={{background:form.primary_color||C.primary,padding:'14px 18px'}}>
                <div style={{fontWeight:800,color:'#fff',fontSize:15}}>{form.company_name||'Your Company'}</div>
                <div style={{color:'rgba(255,255,255,0.7)',fontSize:11,marginTop:2}}>Workforce Operations Platform</div>
              </div>
              <div style={{padding:14,background:C.surface}}>
                <div style={{display:'flex',gap:8,marginBottom:12}}>
                  {['Dashboard','HR','Leave','Projects'].map(m=>(
                    <div key={m} style={{background:C.elevated,borderRadius:6,padding:'4px 10px',fontSize:10,color:C.muted}}>{m}</div>
                  ))}
                </div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
                  {[['Active Employees','47'],['On Leave','3']].map(([l,v])=>(
                    <div key={l} style={{background:C.card,borderRadius:8,padding:'10px 12px',borderTop:`3px solid ${form.primary_color||C.primary}`}}>
                      <div style={{fontSize:10,color:C.dim,textTransform:'uppercase',letterSpacing:'0.08em'}}>{l}</div>
                      <div style={{fontSize:22,fontWeight:900,color:C.text}}>{v}</div>
                    </div>
                  ))}
                </div>
                <div style={{marginTop:10,background:form.secondary_color||C.secondary,borderRadius:8,padding:'8px 12px'}}>
                  <div style={{fontSize:11,fontWeight:700,color:'#fff'}}>◉ Active alerts / actions</div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      )}

      {tab==='modules' && (
        <Card>
          <div style={{fontSize:13,fontWeight:700,color:C.text,marginBottom:4}}>Module Licensing</div>
          <div style={{fontSize:12,color:C.muted,marginBottom:16}}>Enable or disable modules for this tenant. Disabled modules are hidden from the sidebar.</div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))',gap:10}}>
            {(modules??[]).map((m:any)=>(
              <div key={m.id} style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 14px',background:C.surface,borderRadius:10,border:`1px solid ${m.enabled?C.border:C.border+'44'}`}}>
                <div>
                  <div style={{fontSize:13,fontWeight:700,color:m.enabled?C.text:C.dim}}>{m.module_key}</div>
                  <div style={{fontSize:10,color:m.enabled?C.success:C.dim}}>{m.enabled?'Enabled':'Disabled'}</div>
                </div>
                <button onClick={()=>toggleModule(m.module_key, m.enabled)} style={{background:m.enabled?C.success+'22':C.dim+'22',color:m.enabled?C.success:C.dim,border:`1px solid ${m.enabled?C.success+'44':C.dim+'33'}`,borderRadius:20,padding:'4px 12px',fontSize:11,fontWeight:700,cursor:'pointer',transition:'all 0.15s'}}>
                  {m.enabled?'● On':'○ Off'}
                </button>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
